import { useCallback, useEffect, useRef, useState } from 'react';
import { RiderState } from '../game/types';

export type GamepadButtonId =
  | 'lt'
  | 'lb'
  | 'l3'
  | 'rt'
  | 'rb'
  | 'r3'
  | 'dpad_up'
  | 'dpad_down'
  | 'dpad_left'
  | 'dpad_right'
  | 'y'
  | 'x'
  | 'b'
  | 'a'
  | 'view'
  | 'menu';

interface GamepadOverlayProps {
  riderState: RiderState;
  uiNavOpen: boolean;
  onAudioWake: () => void;
  onLeftStick: (x: number, y: number) => void;
  onRightStick: (x: number, y: number) => void;
  onHoldButton: (id: GamepadButtonId, pressed: boolean) => void;
  onPressButton: (id: GamepadButtonId) => void;
}

interface CutoutStickProps {
  label: string;
  onChange: (x: number, y: number) => void;
  onActivate: () => void;
  externalX?: number;
  externalY?: number;
}

function CutoutStick({
  label,
  onChange,
  onActivate,
  externalX = 0,
  externalY = 0,
}: CutoutStickProps) {
  const padRef = useRef<HTMLDivElement | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const activePointer = useRef<number | null>(null);
  const maxRadius = 32;

  const updateFromClient = useCallback(
    (clientX: number, clientY: number) => {
      const pad = padRef.current;
      if (!pad) return;
      const rect = pad.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      let dx = clientX - cx;
      let dy = clientY - cy;
      const dist = Math.hypot(dx, dy);
      if (dist > maxRadius) {
        dx = (dx / dist) * maxRadius;
        dy = (dy / dist) * maxRadius;
      }
      setKnob({ x: dx, y: dy });
      onChange(dx / maxRadius, dy / maxRadius);
    },
    [onChange]
  );

  const resetStick = useCallback(() => {
    activePointer.current = null;
    setDragging(false);
    setKnob({ x: 0, y: 0 });
    onChange(0, 0);
  }, [onChange]);

  const dispX = dragging ? knob.x : externalX * maxRadius;
  const dispY = dragging ? knob.y : externalY * maxRadius;

  return (
    <div className="flex flex-col items-center gap-0.5 select-none">
      <div
        ref={padRef}
        onPointerDown={(e) => {
          e.preventDefault();
          onActivate();
          activePointer.current = e.pointerId;
          setDragging(true);
          e.currentTarget.setPointerCapture(e.pointerId);
          updateFromClient(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (activePointer.current !== e.pointerId) return;
          updateFromClient(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (activePointer.current !== e.pointerId) return;
          if (e.currentTarget.hasPointerCapture(e.pointerId)) {
            e.currentTarget.releasePointerCapture(e.pointerId);
          }
          resetStick();
        }}
        onPointerCancel={resetStick}
        className="relative w-[96px] h-[96px] sm:w-[112px] sm:h-[112px] touch-none cursor-grab active:cursor-grabbing flex items-center justify-center"
      >
        <img
          src="/assets/controls/stick_base.png"
          alt=""
          draggable={false}
          className={`pointer-events-none w-full h-full object-contain transition-opacity duration-100 ${
            dragging ? 'opacity-100' : 'opacity-85'
          }`}
        />
        <img
          src="/assets/controls/stick_knob.png"
          alt={label}
          draggable={false}
          className="pointer-events-none absolute w-[48px] h-[48px] sm:w-[56px] sm:h-[56px] object-contain drop-shadow-[0_2px_6px_rgba(0,0,0,0.85)]"
          style={{
            transform: `translate(${dispX}px, ${dispY}px) scale(${dragging ? 1.07 : 1})`,
          }}
        />
      </div>
      <span className="pointer-events-none text-[9px] font-medium text-white/75 tracking-wide drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
        {label}
      </span>
    </div>
  );
}

interface SpriteButtonProps {
  id: GamepadButtonId;
  src: string;
  label: string;
  subLabel?: string;
  className: string;
  active?: boolean;
  highlight?: boolean;
  onHold: (id: GamepadButtonId, pressed: boolean) => void;
  onPress: (id: GamepadButtonId) => void;
  onAudioWake: () => void;
  labelPlacement?: 'bottom' | 'left' | 'right' | 'none';
}

function SpriteButton({
  id,
  src,
  label,
  subLabel,
  className,
  active = false,
  highlight = false,
  onHold,
  onPress,
  onAudioWake,
  labelPlacement = 'bottom',
}: SpriteButtonProps) {
  const [pressed, setPressed] = useState(false);
  const pointerIdRef = useRef<number | null>(null);
  const isDown = pressed || active;

  const release = useCallback(() => {
    if (pointerIdRef.current === null && !pressed) return;
    pointerIdRef.current = null;
    setPressed(false);
    onHold(id, false);
  }, [id, onHold, pressed]);

  return (
    <div
      className={`relative flex items-center justify-center select-none ${
        labelPlacement === 'bottom' ? 'flex-col gap-0.5' : 'flex-row gap-1.5'
      }`}
    >
      {labelPlacement === 'left' && subLabel && (
        <span className="pointer-events-none text-[9px] font-medium text-white/75 drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
          {subLabel}
        </span>
      )}

      <button
        type="button"
        aria-label={`${label}${subLabel ? ` (${subLabel})` : ''}`}
        title={subLabel ? `${label}: ${subLabel}` : label}
        onPointerDown={(e) => {
          e.preventDefault();
          e.currentTarget.blur();
          onAudioWake();
          pointerIdRef.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          setPressed(true);
          onHold(id, true);
          onPress(id);
        }}
        onPointerUp={(e) => {
          if (pointerIdRef.current !== e.pointerId) return;
          if (e.currentTarget.hasPointerCapture(e.pointerId)) {
            e.currentTarget.releasePointerCapture(e.pointerId);
          }
          release();
        }}
        onPointerCancel={release}
        onLostPointerCapture={release}
        className={`relative touch-none bg-transparent border-0 p-0 focus:outline-none transition-transform duration-75 ${className}`}
        style={{
          transform: isDown ? 'scale(0.9)' : 'scale(1)',
          filter: isDown
            ? 'brightness(1.45) drop-shadow(0 0 8px rgba(251,191,36,0.85))'
            : highlight
              ? 'brightness(1.25) drop-shadow(0 0 6px rgba(251,191,36,0.65))'
              : 'drop-shadow(0 2px 5px rgba(0,0,0,0.7))',
        }}
      >
        <img
          src={src}
          alt={label}
          draggable={false}
          className="pointer-events-none w-full h-full object-contain"
        />
      </button>

      {labelPlacement === 'bottom' && subLabel && (
        <span className="pointer-events-none text-[9px] font-medium text-white/75 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
          {subLabel}
        </span>
      )}
      {labelPlacement === 'right' && subLabel && (
        <span className="pointer-events-none text-[9px] font-medium text-white/75 drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
          {subLabel}
        </span>
      )}
    </div>
  );
}

export function GamepadOverlay({
  riderState,
  uiNavOpen,
  onAudioWake,
  onLeftStick,
  onRightStick,
  onHoldButton,
  onPressButton,
}: GamepadOverlayProps) {
  const [hwActive, setHwActive] = useState<Partial<Record<GamepadButtonId, boolean>>>({});
  const [hwSticks, setHwSticks] = useState({ lx: 0, ly: 0, rx: 0, ry: 0 });
  const prevHwBtns = useRef<Partial<Record<GamepadButtonId, boolean>>>({});
  const hadHwAxes = useRef({ left: false, right: false });

  // Physical Gamepad API support (Xbox / PlayStation / Bluetooth controllers)
  useEffect(() => {
    let raf = 0;

    const deadzone = (v: number) => (Math.abs(v) < 0.14 ? 0 : (v - Math.sign(v) * 0.14) / 0.86);

    const poll = () => {
      const pads = navigator.getGamepads?.();
      const pad = pads ? Array.from(pads).find((p) => p && p.connected) : undefined;

      if (pad) {
        const lx = deadzone(pad.axes[0] ?? 0);
        const ly = deadzone(pad.axes[1] ?? 0);
        const rx = deadzone(pad.axes[2] ?? 0);
        const ry = deadzone(pad.axes[3] ?? 0);

        if (lx !== 0 || ly !== 0 || hadHwAxes.current.left) {
          onLeftStick(lx, ly);
          hadHwAxes.current.left = lx !== 0 || ly !== 0;
        }
        if (rx !== 0 || ry !== 0 || hadHwAxes.current.right) {
          onRightStick(rx, ry);
          hadHwAxes.current.right = rx !== 0 || ry !== 0;
        }

        const btn = (idx: number) => Boolean(pad.buttons[idx]?.pressed);
        const val = (idx: number) => (pad.buttons[idx]?.value ?? 0) > 0.25 || btn(idx);

        const state: Record<GamepadButtonId, boolean> = {
          a: btn(0),
          b: btn(1),
          x: btn(2),
          y: btn(3),
          lb: btn(4),
          rb: btn(5),
          lt: val(6),
          rt: val(7),
          view: btn(8),
          menu: btn(9),
          l3: btn(10),
          r3: btn(11),
          dpad_up: btn(12),
          dpad_down: btn(13),
          dpad_left: btn(14),
          dpad_right: btn(15),
        };

        let changed = false;
        (Object.keys(state) as GamepadButtonId[]).forEach((id) => {
          const cur = state[id];
          const prev = Boolean(prevHwBtns.current[id]);
          if (cur !== prev) {
            changed = true;
            if (cur) {
              onAudioWake();
              onPressButton(id);
            }
            onHoldButton(id, cur);
          }
        });

        if (changed) {
          prevHwBtns.current = state;
          setHwActive(state);
        }
        setHwSticks((prev) =>
          Math.abs(prev.lx - lx) > 0.02 ||
          Math.abs(prev.ly - ly) > 0.02 ||
          Math.abs(prev.rx - rx) > 0.02 ||
          Math.abs(prev.ry - ry) > 0.02
            ? { lx, ly, rx, ry }
            : prev
        );
      }

      raf = requestAnimationFrame(poll);
    };

    raf = requestAnimationFrame(poll);
    return () => cancelAnimationFrame(raf);
  }, [onAudioWake, onHoldButton, onLeftStick, onPressButton, onRightStick]);

  const onFoot = riderState === 'on_foot';

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none">
      {/* Top-Left Shoulder & Stick Click Rail (below telemetry strip) */}
      <div className="pointer-events-auto fixed left-3 sm:left-5 top-[128px] sm:top-[136px] flex flex-col items-start gap-2">
        <SpriteButton
          id="lt"
          src="/assets/controls/lt.png"
          label="LT"
          subLabel={onFoot ? 'Trás' : 'Freio / RL'}
          className="w-[54px] h-[30px] sm:w-[66px] sm:h-[36px]"
          active={hwActive.lt}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="right"
        />
        <SpriteButton
          id="lb"
          src="/assets/controls/lb.png"
          label="LB"
          subLabel={onFoot ? 'Correr' : 'Embreagem'}
          className="w-[54px] h-[30px] sm:w-[66px] sm:h-[36px]"
          active={hwActive.lb}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="right"
        />
        <SpriteButton
          id="l3"
          src="/assets/controls/l3.png"
          label="L3"
          subLabel="Reset"
          className="w-[34px] h-[34px] sm:w-[40px] sm:h-[40px]"
          active={hwActive.l3}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="right"
        />
      </div>

      {/* Top-Right Shoulder & Stick Click Rail (below mini-map) */}
      <div className="pointer-events-auto fixed right-3 sm:right-5 top-[186px] sm:top-[196px] flex flex-col items-end gap-2">
        <SpriteButton
          id="rt"
          src="/assets/controls/rt.png"
          label="RT"
          subLabel={onFoot ? 'Andar' : 'Acelerar'}
          className="w-[54px] h-[30px] sm:w-[66px] sm:h-[36px]"
          active={hwActive.rt}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="left"
        />
        <SpriteButton
          id="rb"
          src="/assets/controls/rb.png"
          label="RB"
          subLabel={onFoot ? 'Salve' : 'Grau'}
          className="w-[54px] h-[30px] sm:w-[66px] sm:h-[36px]"
          active={hwActive.rb}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="left"
        />
        <SpriteButton
          id="r3"
          src="/assets/controls/r3.png"
          label="R3"
          subLabel="Centralizar"
          className="w-[34px] h-[34px] sm:w-[40px] sm:h-[40px]"
          active={hwActive.r3}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
          labelPlacement="left"
        />
      </div>

      {/* Bottom-Left: Left Analog Stick + D-Pad Cross */}
      <div className="pointer-events-auto fixed left-3 sm:left-6 bottom-3 sm:bottom-5 flex items-center gap-3 sm:gap-5">
        <CutoutStick
          label={onFoot ? 'Mover / Virar' : 'Direção / Grau'}
          onChange={onLeftStick}
          onActivate={onAudioWake}
          externalX={hwSticks.lx}
          externalY={hwSticks.ly}
        />

        <div className="flex flex-col items-center gap-0.5">
          <div className="relative w-[86px] h-[86px] sm:w-[100px] sm:h-[100px]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2">
              <SpriteButton
                id="dpad_up"
                src="/assets/controls/dpad_up.png"
                label="Cima"
                subLabel={uiNavOpen ? undefined : 'M+'}
                className="w-[26px] h-[30px] sm:w-[30px] sm:h-[34px]"
                active={hwActive.dpad_up}
                onHold={onHoldButton}
                onPress={onPressButton}
                onAudioWake={onAudioWake}
                labelPlacement="none"
              />
            </div>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2">
              <SpriteButton
                id="dpad_down"
                src="/assets/controls/dpad_down.png"
                label="Baixo"
                subLabel={uiNavOpen ? undefined : 'M-'}
                className="w-[26px] h-[30px] sm:w-[30px] sm:h-[34px]"
                active={hwActive.dpad_down}
                onHold={onHoldButton}
                onPress={onPressButton}
                onAudioWake={onAudioWake}
                labelPlacement="none"
              />
            </div>
            <div className="absolute left-0 top-1/2 -translate-y-1/2">
              <SpriteButton
                id="dpad_left"
                src="/assets/controls/dpad_left.png"
                label="Esquerda"
                className="w-[30px] h-[26px] sm:w-[34px] sm:h-[30px]"
                active={hwActive.dpad_left}
                onHold={onHoldButton}
                onPress={onPressButton}
                onAudioWake={onAudioWake}
                labelPlacement="none"
              />
            </div>
            <div className="absolute right-0 top-1/2 -translate-y-1/2">
              <SpriteButton
                id="dpad_right"
                src="/assets/controls/dpad_right.png"
                label="Direita"
                className="w-[30px] h-[26px] sm:w-[34px] sm:h-[30px]"
                active={hwActive.dpad_right}
                onHold={onHoldButton}
                onPress={onPressButton}
                onAudioWake={onAudioWake}
                labelPlacement="none"
              />
            </div>
          </div>
          <span className="pointer-events-none text-[9px] font-medium text-white/75 drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
            {uiNavOpen ? 'Navegar UI' : 'Marcha / Molejo'}
          </span>
        </div>
      </div>

      {/* Bottom-Center: View (Camera) & Menu (Interface Control) */}
      <div className="pointer-events-auto fixed bottom-2.5 sm:bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4 sm:gap-6">
        <SpriteButton
          id="view"
          src="/assets/controls/btn_view.png"
          label="Câmera"
          subLabel="Câmera"
          className="w-[44px] h-[26px] sm:w-[52px] sm:h-[30px]"
          active={hwActive.view}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
        />
        <SpriteButton
          id="menu"
          src="/assets/controls/btn_menu.png"
          label="Menu"
          subLabel={uiNavOpen ? 'Fechar UI' : 'Interface'}
          className="w-[44px] h-[26px] sm:w-[52px] sm:h-[30px]"
          active={hwActive.menu}
          highlight={uiNavOpen}
          onHold={onHoldButton}
          onPress={onPressButton}
          onAudioWake={onAudioWake}
        />
      </div>

      {/* Bottom-Right: Right Analog Stick (Camera Look) + Y X B A Diamond */}
      <div className="pointer-events-auto fixed right-3 sm:right-6 bottom-3 sm:bottom-5 flex items-center gap-3 sm:gap-5">
        <CutoutStick
          label="Câmera"
          onChange={onRightStick}
          onActivate={onAudioWake}
          externalX={hwSticks.rx}
          externalY={hwSticks.ry}
        />

        <div className="relative w-[108px] h-[108px] sm:w-[124px] sm:h-[124px]">
          <div className="absolute top-0 left-1/2 -translate-x-1/2">
            <SpriteButton
              id="y"
              src="/assets/controls/btn_y.png"
              label="Y"
              subLabel={onFoot ? 'Subir' : 'Descer'}
              className="w-[34px] h-[34px] sm:w-[38px] sm:h-[38px]"
              active={hwActive.y}
              onHold={onHoldButton}
              onPress={onPressButton}
              onAudioWake={onAudioWake}
            />
          </div>
          <div className="absolute left-0 top-1/2 -translate-y-1/2">
            <SpriteButton
              id="x"
              src="/assets/controls/btn_x.png"
              label="X"
              subLabel={uiNavOpen ? 'Som' : onFoot ? 'Salve' : 'Sem Mão'}
              className="w-[34px] h-[34px] sm:w-[38px] sm:h-[38px]"
              active={hwActive.x}
              onHold={onHoldButton}
              onPress={onPressButton}
              onAudioWake={onAudioWake}
            />
          </div>
          <div className="absolute right-0 top-1/2 -translate-y-1/2">
            <SpriteButton
              id="b"
              src="/assets/controls/btn_b.png"
              label="B"
              subLabel={uiNavOpen ? 'Voltar' : onFoot ? 'Correr' : 'Burnout'}
              className="w-[34px] h-[34px] sm:w-[38px] sm:h-[38px]"
              active={hwActive.b}
              onHold={onHoldButton}
              onPress={onPressButton}
              onAudioWake={onAudioWake}
            />
          </div>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2">
            <SpriteButton
              id="a"
              src="/assets/controls/btn_a.png"
              label="A"
              subLabel={uiNavOpen ? 'Confirmar' : onFoot ? 'Pular' : 'Freio Pé'}
              className="w-[34px] h-[34px] sm:w-[38px] sm:h-[38px]"
              active={hwActive.a}
              onHold={onHoldButton}
              onPress={onPressButton}
              onAudioWake={onAudioWake}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
