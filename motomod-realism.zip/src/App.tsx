import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bike,
  Camera,
  ChevronDown,
  ChevronUp,
  Footprints,
  Gamepad2,
  Hand,
  Maximize2,
  Minimize2,
  Monitor,
  RotateCcw,
  Sliders,
  Smartphone,
  Sparkles,
  Volume2,
  VolumeX,
  Wrench,
  X,
} from 'lucide-react';
import { GamepadButtonId, GamepadOverlay } from './components/GamepadOverlay';
import { GameEngine } from './game/GameEngine';
import { PLAZA_RECT, STREETS, STUNT_RAMPS } from './game/RoadTerrain';
import {
  BikeCaliperColor,
  BikeCustomization,
  BikeExhaustStyle,
  BikeFenderStyle,
  BikeHeadlightTint,
  BikeMirrorStyle,
  BikePaintColor,
  BikePaintFinish,
  BikeSeatColor,
  BikeWheelColor,
  CameraMode,
  DEFAULT_BIKE_CUSTOMIZATION,
  EmoteId,
  GloveStyle,
  GraphicsQuality,
  LoadProgress,
  PhysicsPreset,
  ScreenStretchMode,
  TelemetryState,
} from './game/types';

const INITIAL_TELEMETRY: TelemetryState = {
  speedKmh: 0,
  rpm: 1450,
  maxRpm: 11000,
  gear: 1,
  wheelieAngleDeg: 0,
  stoppieAngleDeg: 0,
  leanAngleDeg: 0,
  frontSuspRatio: 0.25,
  rearSuspRatio: 0.27,
  rearSlip: 0,
  isWheelie: false,
  isBalancePoint: false,
  isScrape: false,
  isStoppie: false,
  isAirborne: false,
  isNoHand: false,
  activeEmote: 'none',
  revLimiter: false,
  clutchEngaged: true,
  grauDistanceM: 0,
  grauDurationS: 0,
  currentCombo: 0,
  totalScore: 0,
  bestGrauDistanceM: 0,
  bestCombo: 0,
  crashed: false,
  crashReason: '',
  posX: -65,
  posZ: 0,
  yawRad: 0,
  riderState: 'mounted',
  nearBike: true,
  dismountHint: '',
  isPhoneOpen: false,
  phoneApp: 'home',
  helmetOn: true,
  helmetAnimating: false,
  bikeModel: 'cg_160',
};

const CAMERA_OPTIONS: { id: CameraMode; label: string }[] = [
  { id: 'first_person', label: '1ª Pessoa' },
  { id: 'third_person', label: '3ª Pessoa' },
  { id: 'moto_vlog', label: 'Moto Vlog' },
  { id: 'free_orbit', label: 'Livre' },
];

const PHYSICS_OPTIONS: { id: PhysicsPreset; label: string }[] = [
  { id: 'mx_pro', label: 'MX Pro' },
  { id: 'simulation', label: 'Simulação' },
  { id: 'assist', label: 'Assistido' },
];

const GLOVE_OPTIONS: { id: GloveStyle; label: string }[] = [
  { id: 'none', label: 'Sem' },
  { id: 'black', label: 'Preta' },
  { id: 'red', label: 'Vermelha' },
  { id: 'white', label: 'Branca' },
];

const GRAPHICS_OPTIONS: { id: GraphicsQuality; label: string }[] = [
  { id: 'low', label: 'Baixo' },
  { id: 'medium', label: 'Médio' },
  { id: 'high', label: 'Alto' },
  { id: 'ultra', label: 'Ultra' },
];

const EMOTE_OPTIONS: { id: Exclude<EmoteId, 'none'>; emoji: string; label: string }[] = [
  { id: 'salve', emoji: '✌️', label: 'Salve' },
  { id: 'hang_loose', emoji: '🤙', label: 'Grau' },
  { id: 'salute', emoji: '🫡', label: 'Continência' },
  { id: 'flex', emoji: '💪', label: 'Força' },
  { id: 'celebrate', emoji: '🙌', label: 'Comemorar' },
  { id: 'clap', emoji: '👏', label: 'Palmas' },
  { id: 'middle_finger', emoji: '🖕🏻', label: 'Dedo do Meio' },
];

const STRETCH_OPTIONS: { id: ScreenStretchMode; label: string }[] = [
  { id: 'stretched', label: 'Esticada' },
  { id: 'ultra', label: 'Ultra' },
  { id: 'normal', label: 'Normal' },
];

const PAINT_SWATCHES: { id: BikePaintColor; label: string; hex: string }[] = [
  { id: 'titan_red', label: 'Vermelho Titan', hex: '#d91e18' },
  { id: 'black', label: 'Preta', hex: '#1c1f26' },
  { id: 'white', label: 'Branca', hex: '#f1f5f9' },
  { id: 'blue', label: 'Azul', hex: '#1d4ed8' },
  { id: 'green', label: 'Verde', hex: '#16a34a' },
  { id: 'yellow', label: 'Ouro', hex: '#eab308' },
  { id: 'purple', label: 'Roxa', hex: '#7e22ce' },
  { id: 'nardo_gray', label: 'Nardo', hex: '#64748b' },
];

const PAINT_FINISH_OPTIONS: { id: BikePaintFinish; label: string }[] = [
  { id: 'gloss', label: 'Brilhante' },
  { id: 'matte', label: 'Fosco' },
  { id: 'chrome', label: 'Cromado' },
];

const WHEEL_SWATCHES: { id: BikeWheelColor; label: string; hex: string }[] = [
  { id: 'original', label: 'Preta', hex: '#23262f' },
  { id: 'gold', label: 'Dourada', hex: '#d9a11b' },
  { id: 'red', label: 'Vermelha', hex: '#dc2626' },
  { id: 'white', label: 'Branca', hex: '#f1f5f9' },
  { id: 'blue', label: 'Azul', hex: '#2563eb' },
  { id: 'bronze', label: 'Bronze', hex: '#92400e' },
  { id: 'chrome', label: 'Cromo', hex: '#cbd5e1' },
];

const EXHAUST_OPTIONS: { id: BikeExhaustStyle; label: string }[] = [
  { id: 'original', label: 'Original' },
  { id: 'titanium', label: 'Titânio' },
  { id: 'black', label: 'Preto' },
  { id: 'gold', label: 'Dourado' },
  { id: 'shorty', label: 'Só o Cano' },
];

const FENDER_OPTIONS: { id: BikeFenderStyle; label: string }[] = [
  { id: 'original', label: 'Original' },
  { id: 'paint', label: 'Cor Moto' },
  { id: 'carbon', label: 'Carbono' },
  { id: 'hidden', label: 'Sem' },
];

const MIRROR_OPTIONS: { id: BikeMirrorStyle; label: string }[] = [
  { id: 'stock', label: 'Com Retrovisor' },
  { id: 'removed', label: 'Sem Retrovisor' },
];

const SEAT_OPTIONS: { id: BikeSeatColor; label: string; hex: string }[] = [
  { id: 'black', label: 'Preto', hex: '#1e2026' },
  { id: 'red', label: 'Vermelho', hex: '#b91c1c' },
  { id: 'brown', label: 'Café', hex: '#7c3f1d' },
  { id: 'white', label: 'Branco', hex: '#e2e8f0' },
];

const HEADLIGHT_OPTIONS: { id: BikeHeadlightTint; label: string; hex: string }[] = [
  { id: 'white', label: 'Xenon', hex: '#f8fafc' },
  { id: 'yellow', label: 'Amarelo', hex: '#facc15' },
  { id: 'blue', label: 'Azul', hex: '#38bdf8' },
  { id: 'red', label: 'Vermelho', hex: '#ef4444' },
];

const CALIPER_OPTIONS: { id: BikeCaliperColor; label: string; hex: string }[] = [
  { id: 'original', label: 'Original', hex: '#3b3f4a' },
  { id: 'red', label: 'Vermelha', hex: '#dc2626' },
  { id: 'gold', label: 'Dourada', hex: '#d9a11b' },
  { id: 'green', label: 'Verde', hex: '#22c55e' },
  { id: 'blue', label: 'Azul', hex: '#2563eb' },
];

const WORKSHOP_PRESETS: { label: string; config: BikeCustomization }[] = [
  { label: 'Original', config: DEFAULT_BIKE_CUSTOMIZATION },
  {
    label: 'Mandrake',
    config: {
      paintColor: 'black',
      paintFinish: 'matte',
      wheelColor: 'gold',
      exhaustStyle: 'shorty',
      frontFender: 'carbon',
      rearFender: 'carbon',
      mirrors: 'removed',
      seatColor: 'black',
      headlightTint: 'yellow',
      caliperColor: 'gold',
    },
  },
  {
    label: 'Chave Azul',
    config: {
      paintColor: 'blue',
      paintFinish: 'gloss',
      wheelColor: 'white',
      exhaustStyle: 'titanium',
      frontFender: 'paint',
      rearFender: 'paint',
      mirrors: 'removed',
      seatColor: 'black',
      headlightTint: 'blue',
      caliperColor: 'blue',
    },
  },
  {
    label: 'Grau Limpo',
    config: {
      paintColor: 'white',
      paintFinish: 'gloss',
      wheelColor: 'red',
      exhaustStyle: 'shorty',
      frontFender: 'hidden',
      rearFender: 'hidden',
      mirrors: 'removed',
      seatColor: 'red',
      headlightTint: 'white',
      caliperColor: 'red',
    },
  },
];

const BIKE_CUSTOM_STORAGE_KEY = 'grau_favela_bike_custom_v1';
const REFLECTIONS_STORAGE_KEY = 'grau_favela_reflections_v1';
const REAL_GROUND_REF_STORAGE_KEY = 'grau_favela_real_ground_reflection_v1';

const UI_FOCUS_COUNT = 16;

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [loadProgress, setLoadProgress] = useState<LoadProgress>({
    loaded: false,
    percent: 0,
    statusText: 'Inicializando motor 3D...',
    error: null,
  });
  const [telemetry, setTelemetry] = useState<TelemetryState>(INITIAL_TELEMETRY);
  const [cameraMode, setCameraMode] = useState<CameraMode>('first_person');
  const [physicsPreset, setPhysicsPreset] = useState<PhysicsPreset>('simulation');
  const [autoGear, setAutoGear] = useState(true);
  const [molejoLevel, setMolejoLevel] = useState(1.0);
  const [fpFov, setFpFov] = useState(78);
  const [fpCamDist, setFpCamDist] = useState(0);
  const [gloveStyle, setGloveStyle] = useState<GloveStyle>('black');
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>('high');
  const [screenStretch, setScreenStretch] = useState<ScreenStretchMode>('stretched');
  const [reflectionsEnabled, setReflectionsEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(REFLECTIONS_STORAGE_KEY);
      if (saved !== null) return saved === 'true';
    } catch {
      // Ignore storage read issues
    }
    return true;
  });
  const [realGroundReflections, setRealGroundReflections] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(REAL_GROUND_REF_STORAGE_KEY);
      if (saved !== null) return saved === 'true';
    } catch {
      // Ignore storage read issues
    }
    return true;
  });
  const [muted, setMuted] = useState(false);
  const [dockOpen, setDockOpen] = useState(false);
  const [workshopOpen, setWorkshopOpen] = useState(false);
  const [bikeCustom, setBikeCustom] = useState<BikeCustomization>(() => {
    try {
      const saved = localStorage.getItem(BIKE_CUSTOM_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.paintColor === 'ducati_red') parsed.paintColor = 'titan_red';
        return { ...DEFAULT_BIKE_CUSTOMIZATION, ...parsed };
      }
    } catch {
      // Ignore invalid localStorage payload
    }
    return DEFAULT_BIKE_CUSTOMIZATION;
  });
  const [uiNavOpen, setUiNavOpen] = useState(false);
  const [uiFocusIdx, setUiFocusIdx] = useState(0);
  const [showAnalog, setShowAnalog] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedEmote, setSelectedEmote] = useState<Exclude<EmoteId, 'none'>>('salve');
  const emoteHoldRef = useRef<{
    id: Exclude<EmoteId, 'none'>;
    pointerId: number;
    startX: number;
    startY: number;
    startTime: number;
    dragged: boolean;
    wasActive: boolean;
  } | null>(null);
  const canvasTouchDragRef = useRef<number | null>(null);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const engine = new GameEngine(
      mount,
      (progress) => setLoadProgress(progress),
      (t) => setTelemetry(t)
    );
    engine.setBikeModel('cg_160');
    engine.setBikeCustomization(bikeCustom);
    engine.setReflectionsEnabled(reflectionsEnabled);
    engine.setRealGroundReflectionEnabled(realGroundReflections);
    engineRef.current = engine;

    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'KeyH') {
        setDockOpen((prev) => {
          const next = !prev;
          if (!next) setUiNavOpen(false);
          return next;
        });
      } else if (e.code === 'KeyV') {
        setCameraMode(engine.cameraMode);
      } else if (e.code === 'KeyG') {
        setAutoGear((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      window.removeEventListener('keydown', onKey);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleCameraChange = useCallback((mode: CameraMode) => {
    setCameraMode(mode);
    engineRef.current?.setCameraMode(mode);
  }, []);

  const handleCycleCamera = useCallback(() => {
    const next = engineRef.current?.cycleCameraMode();
    if (next) setCameraMode(next);
  }, []);

  const handlePresetChange = useCallback((preset: PhysicsPreset) => {
    setPhysicsPreset(preset);
    engineRef.current?.setPhysicsPreset(preset);
  }, []);

  const handleAutoGearToggle = useCallback(() => {
    setAutoGear((prev) => {
      const next = !prev;
      engineRef.current?.setAutoGear(next);
      return next;
    });
  }, []);

  const handleMolejoChange = useCallback((val: number) => {
    setMolejoLevel(val);
    if (engineRef.current) {
      engineRef.current.molejoMultiplier = val;
    }
  }, []);

  const handleFovChange = useCallback(
    (val: number) => {
      setFpFov(val);
      engineRef.current?.setFirstPersonConfig(val, fpCamDist);
    },
    [fpCamDist]
  );

  const handleCamDistChange = useCallback(
    (val: number) => {
      setFpCamDist(val);
      engineRef.current?.setFirstPersonConfig(fpFov, val);
    },
    [fpFov]
  );

  const handleGloveChange = useCallback((style: GloveStyle) => {
    setGloveStyle(style);
    engineRef.current?.setGloveStyle(style);
  }, []);

  const handleGraphicsChange = useCallback((quality: GraphicsQuality) => {
    setGraphicsQuality(quality);
    engineRef.current?.setGraphicsQuality(quality);
  }, []);

  const handleScreenStretchChange = useCallback((mode: ScreenStretchMode) => {
    setScreenStretch(mode);
    engineRef.current?.setScreenStretchMode(mode);
  }, []);

  const handleBikeCustomChange = useCallback((patch: Partial<BikeCustomization>) => {
    setBikeCustom((prev) => {
      const next = { ...prev, ...patch };
      engineRef.current?.setBikeCustomization(next);
      try {
        localStorage.setItem(BIKE_CUSTOM_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota issues
      }
      return next;
    });
  }, []);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      engineRef.current?.audio.start();
      engineRef.current?.audio.setMuted(next);
      return next;
    });
  }, []);

  const handleReset = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.resetBike();
  }, []);

  const handleToggleDismount = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.toggleDismount();
  }, []);

  const handleTogglePhone = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.togglePhone();
  }, []);

  const handleToggleHelmet = useCallback(() => {
    engineRef.current?.audio.start();
    engineRef.current?.toggleHelmet();
  }, []);

  const handleToggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen may be restricted by parent iframe policy
    }
  }, []);

  const handleAnalogMove = useCallback((x: number, y: number) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.setVirtualInput('steer', x);
    eng.setVirtualStickY(y);
    // Deadzone on Y; only pull Grau when pulling analog backward (y > deadzone).
    // Pushing analog forward is disabled per user request (no front dive / stoppie maneuver).
    const deadzone = 0.28;
    const pitch = y > deadzone ? (y - deadzone) / (1 - deadzone) : 0;
    eng.setVirtualInput('riderPitch', pitch);
  }, []);

  const handleToggleReflections = useCallback(() => {
    setReflectionsEnabled((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(REFLECTIONS_STORAGE_KEY, String(next));
      } catch {
        // Ignore storage write issues
      }
      engineRef.current?.setReflectionsEnabled(next);
      return next;
    });
  }, []);

  const handleToggleRealGroundReflections = useCallback(() => {
    setRealGroundReflections((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(REAL_GROUND_REF_STORAGE_KEY, String(next));
      } catch {
        // Ignore storage write issues
      }
      engineRef.current?.setRealGroundReflectionEnabled(next);
      return next;
    });
  }, []);

  const handleRightStickMove = useCallback((x: number, y: number) => {
    engineRef.current?.setVirtualCameraLook(x, y);
  }, []);

  const handleAudioWake = useCallback(() => {
    engineRef.current?.audio.start();
  }, []);

  const mapClientToDrag = useCallback((clientX: number, clientY: number) => {
    const w = Math.max(1, window.innerWidth);
    const h = Math.max(1, window.innerHeight);
    return {
      nx: (clientX / w) * 2 - 1,
      ny: -((clientY / h) * 2 - 1),
    };
  }, []);

  const handleEmotePointerDown = useCallback(
    (id: Exclude<EmoteId, 'none'>, e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      e.currentTarget.blur();
      const eng = engineRef.current;
      eng?.audio.start();
      const wasActive = telemetry.activeEmote === id;
      setSelectedEmote(id);
      emoteHoldRef.current = {
        id,
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        startTime: performance.now(),
        dragged: false,
        wasActive,
      };
      eng?.startHoldEmote(id, 0, 0.04);
    },
    [telemetry.activeEmote]
  );

  const handleEmotePointerMove = useCallback(
    (e: React.PointerEvent<HTMLButtonElement>) => {
      const hold = emoteHoldRef.current;
      if (!hold || hold.pointerId !== e.pointerId) return;
      const dist = Math.hypot(e.clientX - hold.startX, e.clientY - hold.startY);
      if (!hold.dragged && dist > 8) {
        hold.dragged = true;
      }
      if (hold.dragged) {
        const { nx, ny } = mapClientToDrag(e.clientX, e.clientY);
        engineRef.current?.moveEmoteDrag(nx, ny);
      }
    },
    [mapClientToDrag]
  );

  const handleEmotePointerEnd = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    const hold = emoteHoldRef.current;
    if (!hold || hold.pointerId !== e.pointerId) return;
    emoteHoldRef.current = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    const elapsed = performance.now() - hold.startTime;
    const eng = engineRef.current;
    if (!eng) return;

    if (hold.dragged || elapsed >= 260) {
      // User held or dragged the emoji -> lower arm cleanly on release
      eng.stopHoldEmote(false);
    } else if (hold.wasActive) {
      eng.stopHoldEmote(false);
    } else {
      // Quick tap keeps gesture up in front of screen so user can also drag anywhere on screen
      eng.stopHoldEmote(true, 3.6);
    }
  }, []);

  const adjustFocusedUi = useCallback(
    (dir: -1 | 1 | 0) => {
      const cycle = <T,>(arr: { id: T }[], cur: T, step: number) => {
        const idx = arr.findIndex((item) => item.id === cur);
        const nextIdx = (Math.max(0, idx) + step + arr.length) % arr.length;
        return arr[nextIdx].id;
      };

      switch (uiFocusIdx) {
        case 0:
          handleCameraChange(cycle(CAMERA_OPTIONS, cameraMode, dir === 0 ? 1 : dir));
          break;
        case 1:
          handlePresetChange(cycle(PHYSICS_OPTIONS, physicsPreset, dir === 0 ? 1 : dir));
          break;
        case 2:
          handleGloveChange(cycle(GLOVE_OPTIONS, gloveStyle, dir === 0 ? 1 : dir));
          break;
        case 3:
          handleGraphicsChange(cycle(GRAPHICS_OPTIONS, graphicsQuality, dir === 0 ? 1 : dir));
          break;
        case 4: {
          const step = dir === 0 ? 0.1 : dir * 0.1;
          handleMolejoChange(Math.round(Math.min(1.8, Math.max(0.3, molejoLevel + step)) * 10) / 10);
          break;
        }
        case 5: {
          const step = dir === 0 ? 0.02 : dir * 0.02;
          handleCamDistChange(
            Math.round(Math.min(0.24, Math.max(-0.18, fpCamDist + step)) * 100) / 100
          );
          break;
        }
        case 6: {
          const step = dir === 0 ? 3 : dir * 3;
          handleFovChange(Math.min(115, Math.max(65, fpFov + step)));
          break;
        }
        case 7:
          handleAutoGearToggle();
          break;
        case 8:
          setShowAnalog((v) => !v);
          break;
        case 9:
          handleToggleMute();
          break;
        case 10:
          handleToggleDismount();
          break;
        case 11:
          void handleToggleFullscreen();
          break;
        case 12:
          handleReset();
          break;
        case 13:
          handleScreenStretchChange(cycle(STRETCH_OPTIONS, screenStretch, dir === 0 ? 1 : dir));
          break;
        case 14:
          handleToggleReflections();
          break;
        case 15:
          handleToggleRealGroundReflections();
          break;
        default:
          break;
      }
    },
    [
      cameraMode,
      fpCamDist,
      fpFov,
      gloveStyle,
      graphicsQuality,
      handleAutoGearToggle,
      handleCamDistChange,
      handleCameraChange,
      handleFovChange,
      handleGloveChange,
      handleGraphicsChange,
      handleMolejoChange,
      handlePresetChange,
      handleReset,
      handleScreenStretchChange,
      handleToggleDismount,
      handleToggleFullscreen,
      handleToggleMute,
      handleToggleReflections,
      handleToggleRealGroundReflections,
      molejoLevel,
      physicsPreset,
      screenStretch,
      uiFocusIdx,
    ]
  );

  const handleGamepadHold = useCallback(
    (id: GamepadButtonId, pressed: boolean) => {
      const eng = engineRef.current;
      if (!eng) return;

      if (uiNavOpen) {
        if (id === 'lt') eng.setVirtualInput('frontBrake', pressed ? 1 : 0);
        if (id === 'rt') eng.setVirtualInput('throttle', pressed ? 1 : 0);
        return;
      }

      const onFoot = telemetry.riderState === 'on_foot';
      switch (id) {
        case 'rt':
          eng.setVirtualInput('throttle', pressed ? 1 : 0);
          break;
        case 'lt':
          eng.setVirtualInput('frontBrake', pressed ? 1 : 0);
          break;
        case 'rb':
          if (onFoot) {
            eng.setVirtualInput('noHand', pressed);
          } else {
            eng.setVirtualInput('riderPitch', pressed ? 1 : 0);
          }
          break;
        case 'lb':
          eng.setVirtualInput('clutch', pressed);
          break;
        case 'a':
          eng.setVirtualInput('rearBrake', pressed ? 1 : 0);
          break;
        case 'x':
          eng.setVirtualInput('noHand', pressed);
          break;
        case 'b':
          if (onFoot) {
            eng.setVirtualInput('clutch', pressed);
          } else {
            eng.setVirtualInput('burnout', pressed);
          }
          break;
        case 'dpad_left':
          eng.setVirtualInput('molejo', pressed ? -molejoLevel : 0);
          break;
        case 'dpad_right':
          eng.setVirtualInput('molejo', pressed ? molejoLevel : 0);
          break;
        default:
          break;
      }
    },
    [molejoLevel, telemetry.riderState, uiNavOpen]
  );

  const handleGamepadPress = useCallback(
    (id: GamepadButtonId) => {
      const eng = engineRef.current;

      if (id === 'menu') {
        setDockOpen((prevDock) => {
          const next = !prevDock;
          setUiNavOpen(next);
          return next;
        });
        return;
      }

      if (id === 'view') {
        handleCycleCamera();
        return;
      }

      if (id === 'r3') {
        eng?.resetCameraLook();
        return;
      }

      if (id === 'l3') {
        handleReset();
        return;
      }

      if (uiNavOpen) {
        switch (id) {
          case 'dpad_up':
            setUiFocusIdx((i) => (i - 1 + UI_FOCUS_COUNT) % UI_FOCUS_COUNT);
            break;
          case 'dpad_down':
            setUiFocusIdx((i) => (i + 1) % UI_FOCUS_COUNT);
            break;
          case 'dpad_left':
            adjustFocusedUi(-1);
            break;
          case 'dpad_right':
            adjustFocusedUi(1);
            break;
          case 'a':
            adjustFocusedUi(0);
            break;
          case 'x':
            handleToggleMute();
            break;
          case 'b':
            setUiNavOpen(false);
            setDockOpen(false);
            break;
          case 'y':
            handleToggleDismount();
            break;
          default:
            break;
        }
        return;
      }

      if (id === 'y') {
        handleToggleDismount();
      } else if (id === 'dpad_up') {
        eng?.shiftUp();
      } else if (id === 'dpad_down') {
        eng?.shiftDown();
      }
    },
    [
      adjustFocusedUi,
      handleCycleCamera,
      handleReset,
      handleToggleDismount,
      handleToggleMute,
      uiNavOpen,
    ]
  );

  const rpmRatio = Math.min(1, telemetry.rpm / telemetry.maxRpm);
  const wheelieTargetPct = Math.min(100, Math.max(0, (telemetry.wheelieAngleDeg / 90) * 100));
  const speedIntensity =
    telemetry.riderState === 'mounted'
      ? Math.min(1, Math.max(0, (telemetry.speedKmh - 55) / 145))
      : 0;

  return (
    <div className="fixed inset-0 w-screen h-dvh overflow-hidden bg-[#0b0d11] text-zinc-100">
      {/* Dedicated WebGL Canvas Container */}
      <div
        ref={canvasMountRef}
        className="fixed inset-0 w-full h-full touch-none"
        onPointerDown={(e) => {
          if (e.pointerType !== 'mouse' && engineRef.current?.isEmoteActive()) {
            canvasTouchDragRef.current = e.pointerId;
            e.currentTarget.setPointerCapture(e.pointerId);
            const { nx, ny } = mapClientToDrag(e.clientX, e.clientY);
            engineRef.current.moveEmoteDrag(nx, ny);
          }
        }}
        onPointerMove={(e) => {
          if (e.pointerType !== 'mouse' && canvasTouchDragRef.current === e.pointerId) {
            const { nx, ny } = mapClientToDrag(e.clientX, e.clientY);
            engineRef.current?.moveEmoteDrag(nx, ny);
          }
        }}
        onPointerUp={(e) => {
          if (canvasTouchDragRef.current === e.pointerId) {
            canvasTouchDragRef.current = null;
            if (e.currentTarget.hasPointerCapture(e.pointerId)) {
              e.currentTarget.releasePointerCapture(e.pointerId);
            }
          }
        }}
        onPointerCancel={(e) => {
          if (canvasTouchDragRef.current === e.pointerId) {
            canvasTouchDragRef.current = null;
          }
        }}
      />

      {/* Subtle First-Person Helmet Visor Rim Vignette */}
      {loadProgress.loaded && cameraMode === 'first_person' && (
        <div
          className="pointer-events-none fixed inset-0 z-10"
          style={{
            background:
              'radial-gradient(ellipse 86% 80% at 50% 48%, rgba(0,0,0,0) 68%, rgba(8,10,14,0.42) 90%, rgba(5,6,9,0.82) 100%)',
          }}
        />
      )}

      {/* High-Speed Peripheral Wind Streaks & Speed Tunnel Effect */}
      {loadProgress.loaded && speedIntensity > 0.02 && cameraMode !== 'free_orbit' && (
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="pointer-events-none fixed inset-0 z-10 w-full h-full"
          opacity={speedIntensity * 0.55}
          aria-hidden="true"
        >
          {[
            [6, 12, 16, 22],
            [14, 5, 22, 15],
            [86, 5, 78, 15],
            [94, 12, 84, 22],
            [3, 35, 13, 39],
            [97, 35, 87, 39],
            [3, 64, 14, 60],
            [97, 64, 86, 60],
            [8, 86, 18, 76],
            [92, 86, 82, 76],
            [26, 3, 31, 12],
            [74, 3, 69, 12],
          ].map(([x1, y1, x2, y2], idx) => (
            <line
              key={idx}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#e2e8f0"
              strokeWidth={0.22}
              strokeLinecap="round"
              strokeOpacity={0.35 + (idx % 3) * 0.16}
            />
          ))}
        </svg>
      )}

      {/* Top-Left Minimal Brand & Digital Moto Cluster */}
      {loadProgress.loaded && (
        <header className="pointer-events-none fixed top-4 left-4 z-20 flex flex-col gap-2">
          <div className="pointer-events-auto flex items-center gap-3 px-3.5 py-2 rounded-lg bg-[#0d1016]/85 border border-white/10">
            <h1 className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap">
              Grau Favela
            </h1>
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 text-xs font-medium text-zinc-200 whitespace-nowrap">
              <Bike className="w-3.5 h-3.5 text-amber-400" />
              <span>CG 160 Titan</span>
            </div>
            <span className="text-xs text-zinc-500" aria-hidden="true">
              ·
            </span>
            <span className="text-xs text-zinc-300 font-mono-num whitespace-nowrap">
              Recorde {telemetry.bestGrauDistanceM.toFixed(1)} m
            </span>
            <span className="text-xs text-zinc-500" aria-hidden="true">
              ·
            </span>
            <span className="text-xs text-amber-400 font-mono-num whitespace-nowrap">
              {telemetry.totalScore} pts
            </span>
          </div>

          {/* Compact MX Bikes Telemetry Strip */}
          <div className="flex items-center gap-4 px-3.5 py-2.5 rounded-lg bg-[#0d1016]/85 border border-white/10">
            <div className="flex items-baseline gap-1.5">
              <span className="font-display text-3xl font-bold leading-none font-mono-num text-white">
                {telemetry.speedKmh}
              </span>
              <span className="text-[11px] text-zinc-400">km/h</span>
            </div>

            <div className="h-7 w-px bg-white/10" />

            <div className="flex flex-col items-center min-w-[28px]">
              <span className="text-[10px] text-zinc-400 leading-none">Marcha</span>
              <span className="font-display text-xl font-bold leading-tight text-amber-400 font-mono-num">
                {telemetry.gear === 0 ? 'N' : telemetry.gear}
              </span>
            </div>

            <div className="h-7 w-px bg-white/10" />

            <div className="flex flex-col gap-1 w-32">
              <div className="flex justify-between text-[10px] text-zinc-400 font-mono-num leading-none">
                <span>{(telemetry.rpm / 1000).toFixed(1)}k RPM</span>
                <span className={telemetry.revLimiter ? 'text-red-400 font-semibold' : ''}>
                  {telemetry.revLimiter ? 'Corte' : `${Math.abs(telemetry.leanAngleDeg)}°`}
                </span>
              </div>
              <div className="h-1.5 w-full rounded-sm bg-zinc-800 overflow-hidden">
                <div
                  className={`h-full transition-[width] duration-75 ${
                    rpmRatio > 0.88
                      ? 'bg-red-500'
                      : rpmRatio > 0.65
                        ? 'bg-amber-400'
                        : 'bg-emerald-400'
                  }`}
                  style={{ width: `${rpmRatio * 100}%` }}
                />
              </div>
              <div className="flex gap-1.5 pt-0.5">
                <div className="flex-1 h-1 rounded-sm bg-zinc-800 overflow-hidden" title="Suspensão Dianteira">
                  <div
                    className="h-full bg-sky-400"
                    style={{ width: `${Math.min(100, telemetry.frontSuspRatio * 100)}%` }}
                  />
                </div>
                <div className="flex-1 h-1 rounded-sm bg-zinc-800 overflow-hidden" title="Suspensão Traseira">
                  <div
                    className="h-full bg-orange-400"
                    style={{ width: `${Math.min(100, telemetry.rearSuspRatio * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </header>
      )}

      {/* Top-Right Oficina + Fullscreen Buttons + Open-World Mini-Map */}
      {loadProgress.loaded && (
        <div className="fixed top-4 right-4 z-20 flex flex-col items-end gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.currentTarget.blur();
                handleToggleHelmet();
              }}
              title={
                telemetry.helmetOn
                  ? 'Tirar Capacete com animação (K)'
                  : 'Colocar Capacete com animação (K)'
              }
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                telemetry.helmetAnimating
                  ? 'bg-amber-400 text-zinc-950 border-amber-300'
                  : telemetry.helmetOn
                    ? 'bg-[#0d1016]/85 hover:bg-[#171c26] border-white/10 text-zinc-100'
                    : 'bg-emerald-500 text-zinc-950 border-emerald-400'
              }`}
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className={`w-4 h-4 ${
                  telemetry.helmetAnimating || !telemetry.helmetOn ? 'text-zinc-950' : 'text-amber-400'
                }`}
              >
                <path d="M12 3a8 8 0 0 0-8 8v3.5c0 1.4.8 2.6 2 3.1L10 19h7.5a3.5 3.5 0 0 0 3.5-3.5V12a9 9 0 0 0-9-9Z" />
                <path d="M13 8.5h6.5a2.5 2.5 0 0 1 1.5 2.3v1.7a2 2 0 0 1-2 2H14l-1-6Z" />
              </svg>
              <span>{telemetry.helmetOn ? 'Capacete (K)' : 'Sem Capacete (K)'}</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.currentTarget.blur();
                handleTogglePhone();
              }}
              title="Pegar / Guardar iPhone 17 Pro (P)"
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                telemetry.isPhoneOpen
                  ? 'bg-sky-500 text-zinc-950 border-sky-400'
                  : 'bg-[#0d1016]/85 hover:bg-[#171c26] border-white/10 text-zinc-100'
              }`}
            >
              <Smartphone
                className={`w-4 h-4 ${telemetry.isPhoneOpen ? 'text-zinc-950' : 'text-sky-400'}`}
              />
              <span>iPhone (P)</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.currentTarget.blur();
                setWorkshopOpen((v) => !v);
              }}
              title="Oficina — Personalizar peças e pintura da moto"
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                workshopOpen
                  ? 'bg-amber-500 text-zinc-950 border-amber-400'
                  : 'bg-[#0d1016]/85 hover:bg-[#171c26] border-white/10 text-zinc-100'
              }`}
            >
              <Wrench className={`w-4 h-4 ${workshopOpen ? 'text-zinc-950' : 'text-amber-400'}`} />
              <span>Oficina</span>
            </button>

            <button
              type="button"
              onClick={handleToggleFullscreen}
              title={isFullscreen ? 'Sair da Tela Cheia' : 'Tela Cheia'}
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0d1016]/85 hover:bg-[#171c26] border border-white/10 text-xs font-medium text-zinc-100 transition-colors whitespace-nowrap"
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="w-4 h-4 text-amber-400" />
                  <span>Sair Tela Cheia</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-4 h-4 text-amber-400" />
                  <span>Tela Cheia</span>
                </>
              )}
            </button>
          </div>

          <div
            className="p-2 rounded-lg bg-[#0d1016]/85 border border-white/10 flex flex-col gap-1"
            title="Mapa Complexo do Grau"
          >
            <svg
              viewBox="-450 -315 900 555"
              className="w-36 h-24 rounded bg-[#141922] border border-white/5"
            >
              {/* Quadra / Praça */}
              <rect
                x={PLAZA_RECT.minX}
                y={PLAZA_RECT.minZ}
                width={PLAZA_RECT.maxX - PLAZA_RECT.minX}
                height={PLAZA_RECT.maxZ - PLAZA_RECT.minZ}
                fill="#1d4d3e"
                stroke="#34d399"
                strokeOpacity={0.35}
                strokeWidth={3}
              />
              {/* Ruas e Becos do Morro */}
              {STREETS.map((s) => (
                <line
                  key={s.id}
                  x1={s.ax}
                  y1={s.az}
                  x2={s.bx}
                  y2={s.bz}
                  stroke={s.isAlley ? '#d97706' : '#64748b'}
                  strokeWidth={s.halfWidth * 2.2}
                  strokeLinecap="round"
                />
              ))}
              {/* Rampas de Grau */}
              {STUNT_RAMPS.map((r, idx) => (
                <circle key={idx} cx={r.x} cy={r.z} r={7} fill="#fbbf24" />
              ))}
              {/* Jogador */}
              <g
                transform={`translate(${telemetry.posX}, ${telemetry.posZ}) rotate(${
                  (-telemetry.yawRad * 180) / Math.PI
                })`}
              >
                <polygon
                  points="22,0 -13,-12 -6,0 -13,12"
                  fill="#f59e0b"
                  stroke="#ffffff"
                  strokeWidth={3}
                />
              </g>
            </svg>
            <div className="flex items-center justify-between text-[10px] text-zinc-400 leading-none px-0.5">
              <span>Morro ↑</span>
              <span className="text-emerald-400">Quadra</span>
            </div>
          </div>
        </div>
      )}

      {/* Top-Center Live Grau Balance Indicator */}
      {loadProgress.loaded && (telemetry.isWheelie || telemetry.isStoppie || telemetry.crashed) && (
        <div className="pointer-events-none fixed top-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5">
          {telemetry.crashed ? (
            <div className="pointer-events-auto flex items-center gap-3 px-4 py-2.5 rounded-lg bg-[#1a0d0e]/95 border border-red-500/40">
              <div className="flex flex-col">
                <span className="font-display text-base font-bold text-red-400">
                  {telemetry.crashReason}
                </span>
                <span className="text-xs text-zinc-300">
                  Pressione R ou clique em Voltar para levantar a moto
                </span>
              </div>
              <button
                type="button"
                onClick={handleReset}
                className="px-3 py-1.5 rounded-md bg-red-500 hover:bg-red-400 text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Voltar na pista
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0d1016]/85 border border-white/10 min-w-[230px]">
              <div className="flex items-center justify-between w-full gap-4">
                <span
                  className={`font-display text-sm font-bold ${
                    telemetry.isScrape
                      ? 'text-orange-400'
                      : telemetry.isBalancePoint
                        ? 'text-emerald-400'
                        : telemetry.isStoppie
                          ? 'text-sky-400'
                          : 'text-amber-400'
                  }`}
                >
                  {telemetry.isStoppie
                    ? `RL / Stoppie ${telemetry.stoppieAngleDeg}°`
                    : telemetry.isScrape
                      ? `Raspão ${telemetry.wheelieAngleDeg}°`
                      : telemetry.isBalancePoint
                        ? `Ponto do Grau ${telemetry.wheelieAngleDeg}°`
                        : `Grau ${telemetry.wheelieAngleDeg}°`}
                  {telemetry.isNoHand ? ' · Sem Mão' : ''}
                </span>
                {telemetry.isWheelie && (
                  <span className="font-mono-num text-xs text-zinc-200">
                    {telemetry.grauDistanceM.toFixed(1)} m · +{telemetry.currentCombo}
                  </span>
                )}
              </div>

              {telemetry.isWheelie && (
                <div className="relative w-full h-2 rounded-sm bg-zinc-800 overflow-hidden">
                  <div
                    className="absolute top-0 bottom-0 bg-emerald-500/30"
                    style={{ left: '53%', width: '32%' }}
                  />
                  <div
                    className="absolute top-0 bottom-0 bg-orange-500/40"
                    style={{ left: '85%', width: '15%' }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-1.5 bg-white transition-[left] duration-75"
                    style={{ left: `calc(${wheelieTargetPct}% - 3px)` }}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Dismount / On-Foot Hint & Near-Bike Prompt */}
      {loadProgress.loaded &&
        (telemetry.dismountHint || (telemetry.riderState === 'on_foot' && telemetry.nearBike)) &&
        !telemetry.isWheelie &&
        !telemetry.isStoppie &&
        !telemetry.crashed && (
          <div className="pointer-events-none fixed top-4 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5">
            {telemetry.dismountHint ? (
              <div className="px-4 py-2 rounded-lg bg-[#0d1016]/90 border border-amber-500/40 text-xs font-semibold text-amber-300">
                {telemetry.dismountHint}
              </div>
            ) : (
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  handleToggleDismount();
                }}
                className="pointer-events-auto flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0d1016]/90 hover:bg-[#171c26] border border-emerald-400/50 text-xs font-semibold text-emerald-300 shadow-lg transition-colors"
              >
                <Bike className="w-4 h-4" />
                <span>Subir na Moto (Enter / U)</span>
              </button>
            )}
          </div>
        )}

      {/* Quick Emoji Emotes Strip (Hold & drag anywhere on screen, or tap / keys 1-6) */}
      {loadProgress.loaded && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 transition-all duration-150 ${
            telemetry.isWheelie ||
            telemetry.isStoppie ||
            telemetry.crashed ||
            telemetry.dismountHint ||
            (telemetry.riderState === 'on_foot' && telemetry.nearBike)
              ? 'top-[76px]'
              : 'top-4'
          }`}
        >
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-[#0d1016]/85 border border-white/10 shadow-lg">
            {EMOTE_OPTIONS.map((em, idx) => {
              const isActive = telemetry.activeEmote === em.id;
              const isSelected = selectedEmote === em.id;
              return (
                <button
                  key={em.id}
                  type="button"
                  title={`${em.label} (${idx + 1}) · Segure e arraste`}
                  aria-label={`Emote ${em.label}`}
                  onPointerDown={(e) => handleEmotePointerDown(em.id, e)}
                  onPointerMove={handleEmotePointerMove}
                  onPointerUp={handleEmotePointerEnd}
                  onPointerCancel={handleEmotePointerEnd}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-base leading-none transition-transform duration-100 select-none touch-none ${
                    isActive
                      ? 'bg-amber-500 scale-110 shadow-[0_0_10px_rgba(245,158,11,0.75)]'
                      : isSelected
                        ? 'bg-white/15 hover:bg-white/25 ring-1 ring-amber-400/50'
                        : 'hover:bg-white/15 active:scale-95'
                  }`}
                >
                  {em.emoji}
                </button>
              );
            })}
          </div>
          {telemetry.activeEmote !== 'none' && (
            <span className="pointer-events-none px-2.5 py-0.5 rounded-full bg-[#0d1016]/80 border border-amber-500/30 text-[10px] font-medium text-amber-300 whitespace-nowrap">
              Arraste para qualquer lado · o braço segue
            </span>
          )}
          {telemetry.isPhoneOpen && (
            <span className="pointer-events-none px-3 py-0.5 rounded-full bg-[#0d1016]/85 border border-sky-400/35 text-[10px] font-medium text-sky-300 whitespace-nowrap">
              {telemetry.phoneApp === 'maps'
                ? 'Arraste na tela para mover o mapa · + / − Zoom · ‹ Menu · P para guardar'
                : telemetry.phoneApp === 'camera'
                  ? 'Botão branco tira foto · 0,5x / 1x / 2x Zoom · ↻ Selfie · ‹ Menu · P para guardar'
                  : 'Clique em Mapas ou Câmera no iPhone · P para guardar'}
            </span>
          )}
        </div>
      )}

      {/* Transparent Cut-Out Full Game & Interface Gamepad Overlay */}
      {loadProgress.loaded && showAnalog && (
        <GamepadOverlay
          riderState={telemetry.riderState}
          uiNavOpen={uiNavOpen}
          onAudioWake={handleAudioWake}
          onLeftStick={handleAnalogMove}
          onRightStick={handleRightStickMove}
          onHoldButton={handleGamepadHold}
          onPressButton={handleGamepadPress}
        />
      )}

      {/* Collapsible Unified Bottom Control Dock (positioned cleanly above center View/Menu sprites) */}
      {loadProgress.loaded && (dockOpen || !showAnalog) && (
        <div
          className={`fixed left-1/2 -translate-x-1/2 z-30 flex flex-col items-center transition-all duration-200 ${
            showAnalog ? 'bottom-16' : 'bottom-4'
          }`}
          style={{
            maxWidth: 'min(760px, 68vw)',
            transform: dockOpen ? 'translate(-50%, 0)' : 'translate(-50%, calc(100% - 34px))',
          }}
        >
          <button
            type="button"
            onClick={() =>
              setDockOpen((v) => {
                const next = !v;
                if (!next) setUiNavOpen(false);
                return next;
              })
            }
            className="flex items-center gap-1.5 px-3 py-1 rounded-t-lg bg-[#0d1016]/90 border border-b-0 border-white/10 text-[11px] font-medium text-zinc-300 hover:text-white transition-colors whitespace-nowrap"
          >
            {dockOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            <span>{dockOpen ? 'Ocultar Interface (H / ≡)' : 'Interface (H)'}</span>
          </button>

          <div className="w-full px-3.5 py-2.5 rounded-xl bg-[#0d1016]/92 border border-white/10 flex flex-col gap-2 shadow-2xl">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {/* 0: Camera Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 0 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
              >
                <Camera className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {CAMERA_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleCameraChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        cameraMode === opt.id
                          ? 'bg-amber-500 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 1: Physics Preset Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 1 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {PHYSICS_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handlePresetChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        physicsPreset === opt.id
                          ? 'bg-zinc-100 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2: Rider Gloves Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 2 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
                title="Colocar ou trocar luvas do piloto"
              >
                <Hand className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {GLOVE_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleGloveChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        gloveStyle === opt.id
                          ? 'bg-red-500 text-white font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 3: Graphics Quality Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 3 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
                title="Aumentar ou abaixar a qualidade dos gráficos"
              >
                <Monitor className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {GRAPHICS_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleGraphicsChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        graphicsQuality === opt.id
                          ? 'bg-sky-500 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 13: Stretched Screen (Tela Esticada) Switcher */}
              <div
                className={`flex items-center gap-1.5 rounded-lg px-1 py-0.5 transition-colors ${
                  uiNavOpen && uiFocusIdx === 13 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                }`}
                title="Modo de proporção da tela (Tela Esticada)"
              >
                <Maximize2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900/90 border border-white/5">
                  {STRETCH_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleScreenStretchChange(opt.id)}
                      className={`px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        screenStretch === opt.id
                          ? 'bg-amber-500 text-zinc-950 font-semibold'
                          : 'text-zinc-300 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 4..12: Sliders & Interface Actions */}
              <div className="flex flex-wrap items-center justify-center gap-2">
                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 4 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                >
                  <span>Molejo</span>
                  <input
                    type="range"
                    min={0.3}
                    max={1.8}
                    step={0.1}
                    value={molejoLevel}
                    onChange={(e) => handleMolejoChange(parseFloat(e.target.value))}
                    className="w-14 accent-amber-500 cursor-pointer"
                  />
                </label>

                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 5 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                  title="Ajustar distância da câmera em 1ª Pessoa (mais perto ou mais longe)"
                >
                  <span>Dist. 1ª</span>
                  <input
                    type="range"
                    min={-0.18}
                    max={0.24}
                    step={0.02}
                    value={fpCamDist}
                    onChange={(e) => handleCamDistChange(parseFloat(e.target.value))}
                    className="w-16 accent-amber-500 cursor-pointer"
                  />
                  <span className="text-[10px] text-zinc-400 font-mono-num w-9">
                    {fpCamDist <= -0.04 ? 'Perto' : fpCamDist >= 0.06 ? 'Longe' : 'Médio'}
                  </span>
                </label>

                <label
                  className={`flex items-center gap-1.5 text-xs text-zinc-300 whitespace-nowrap rounded-lg px-1.5 py-0.5 ${
                    uiNavOpen && uiFocusIdx === 6 ? 'ring-1 ring-amber-400 bg-amber-500/15' : ''
                  }`}
                  title="Campo de visão (FOV) da câmera"
                >
                  <span>FOV</span>
                  <input
                    type="range"
                    min={65}
                    max={115}
                    step={1}
                    value={fpFov}
                    onChange={(e) => handleFovChange(parseInt(e.target.value, 10))}
                    className="w-16 accent-amber-500 cursor-pointer"
                  />
                  <span className="text-[10px] text-zinc-400 font-mono-num w-6">{fpFov}°</span>
                </label>

                <button
                  type="button"
                  onClick={handleAutoGearToggle}
                  className={`px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 7 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {autoGear ? 'Auto' : 'Manual Q/E'}
                </button>

                <button
                  type="button"
                  onClick={() => setShowAnalog((v) => !v)}
                  title="Mostrar / Ocultar Controles na Tela"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    showAnalog
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  } ${uiNavOpen && uiFocusIdx === 8 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  <Gamepad2 className="w-3.5 h-3.5" />
                  <span>Controles</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleMute}
                  aria-label={muted ? 'Ativar som' : 'Silenciar som'}
                  className={`p-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 transition-colors shrink-0 ${
                    uiNavOpen && uiFocusIdx === 9 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.currentTarget.blur();
                    handleToggleDismount();
                  }}
                  title="Sair / Subir na Moto (Enter, U ou Y)"
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    telemetry.riderState === 'on_foot'
                      ? 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-amber-300'
                  } ${uiNavOpen && uiFocusIdx === 10 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  {telemetry.riderState === 'on_foot' ? (
                    <>
                      <Bike className="w-3.5 h-3.5" />
                      <span>Subir na Moto</span>
                    </>
                  ) : (
                    <>
                      <Footprints className="w-3.5 h-3.5" />
                      <span>Sair da Moto</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => void handleToggleFullscreen()}
                  className={`flex items-center gap-1 px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 11 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  <span>{isFullscreen ? 'Janela' : 'Tela Cheia'}</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.currentTarget.blur();
                    handleReset();
                  }}
                  title="Reiniciar na pista (R ou L3)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors whitespace-nowrap shrink-0 ${
                    uiNavOpen && uiFocusIdx === 12 ? 'ring-2 ring-amber-400' : ''
                  }`}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleReflections}
                  title="Ativar ou desativar reflexos no mapa todo (poças, asfalto, quadra e moto)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    reflectionsEnabled
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                  } ${uiNavOpen && uiFocusIdx === 14 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  <Sparkles className={`w-3.5 h-3.5 ${reflectionsEnabled ? 'text-amber-300' : 'text-zinc-500'}`} />
                  <span>Reflexos: {reflectionsEnabled ? 'Ligado' : 'Desligado'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleRealGroundReflections}
                  title="Ativar ou desativar reflexo real em tempo real no chão (moto, piloto, casas e céu)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    realGroundReflections
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                  } ${uiNavOpen && uiFocusIdx === 15 ? 'ring-2 ring-amber-400' : ''}`}
                >
                  <Sparkles className={`w-3.5 h-3.5 ${realGroundReflections ? 'text-amber-300' : 'text-zinc-500'}`} />
                  <span>Reflexo Chão: {realGroundReflections ? 'Ligado' : 'Desligado'}</span>
                </button>
              </div>
            </div>

            {uiNavOpen ? (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-amber-300 border-t border-white/5 pt-1.5 font-medium">
                <span>▲ / ▼ Navegar</span>
                <span aria-hidden="true">·</span>
                <span>◀ / ▶ Ajustar</span>
                <span aria-hidden="true">·</span>
                <span>A Confirmar</span>
                <span aria-hidden="true">·</span>
                <span>X Som</span>
                <span aria-hidden="true">·</span>
                <span>B / ≡ Fechar</span>
              </div>
            ) : telemetry.riderState === 'on_foot' ? (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-zinc-400 border-t border-white/5 pt-1.5">
                <span>RT / W Andar</span>
                <span aria-hidden="true">·</span>
                <span>LB / Shift Correr</span>
                <span aria-hidden="true">·</span>
                <span>A / Espaço Pular</span>
                <span aria-hidden="true">·</span>
                <span>X / F Salve</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-300 font-medium">Y / Enter Subir na Moto</span>
                <span aria-hidden="true">·</span>
                <span>View / V Câmera</span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-0.5 text-[11px] text-zinc-400 border-t border-white/5 pt-1.5">
                <span>RT / W Acelerar</span>
                <span aria-hidden="true">·</span>
                <span className="text-amber-300 font-medium">RB / Analógico Puxar Grau</span>
                <span aria-hidden="true">·</span>
                <span className="text-red-300 font-medium">A / Espaço Freio Pé</span>
                <span aria-hidden="true">·</span>
                <span>LT Freio / RL</span>
                <span aria-hidden="true">·</span>
                <span>X Sem Mão</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-300 font-medium">Y / Enter Descer</span>
                <span aria-hidden="true">·</span>
                <span>View / V Câmera</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Moto Workshop / Customization Drawer */}
      {loadProgress.loaded && workshopOpen && (
        <aside className="fixed top-16 right-4 z-30 w-80 max-w-[88vw] max-h-[calc(100dvh-100px)] overflow-y-auto rounded-xl bg-[#0d1016]/94 border border-white/15 p-3.5 shadow-2xl flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-400" />
              <h2 className="font-display text-sm font-bold text-white">Oficina da Moto</h2>
            </div>
            <button
              type="button"
              onClick={() => setWorkshopOpen(false)}
              aria-label="Fechar Oficina"
              className="p-1 rounded-md hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Presets rápidos */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Montagens Rápidas</span>
            <div className="grid grid-cols-2 gap-1.5">
              {WORKSHOP_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => handleBikeCustomChange(preset.config)}
                  className="px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-xs font-medium text-zinc-200 transition-colors text-left"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Pintura da carenagem */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Cor da Carenagem</span>
            <div className="flex flex-wrap gap-1.5">
              {PAINT_SWATCHES.map((sw) => {
                const active = bikeCustom.paintColor === sw.id;
                return (
                  <button
                    key={sw.id}
                    type="button"
                    title={sw.label}
                    onClick={() => handleBikeCustomChange({ paintColor: sw.id })}
                    className={`w-7 h-7 rounded-lg border transition-transform ${
                      active
                        ? 'border-amber-400 ring-2 ring-amber-400/60 scale-105'
                        : 'border-white/20 hover:scale-105'
                    }`}
                    style={{ backgroundColor: sw.hex }}
                  />
                );
              })}
            </div>
          </div>

          {/* Acabamento */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Acabamento da Pintura</span>
            <div className="grid grid-cols-3 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              {PAINT_FINISH_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleBikeCustomChange({ paintFinish: opt.id })}
                  className={`py-1 rounded-md text-xs font-medium transition-colors ${
                    bikeCustom.paintFinish === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Rodas / Aros */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Rodas / Aros</span>
            <div className="flex flex-wrap gap-1.5">
              {WHEEL_SWATCHES.map((sw) => {
                const active = bikeCustom.wheelColor === sw.id;
                return (
                  <button
                    key={sw.id}
                    type="button"
                    title={sw.label}
                    onClick={() => handleBikeCustomChange({ wheelColor: sw.id })}
                    className={`w-7 h-7 rounded-full border transition-transform ${
                      active
                        ? 'border-amber-400 ring-2 ring-amber-400/60 scale-105'
                        : 'border-white/20 hover:scale-105'
                    }`}
                    style={{ backgroundColor: sw.hex }}
                  />
                );
              })}
            </div>
          </div>

          {/* Escapamento */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Escapamento</span>
            <div className="flex flex-wrap gap-1">
              {EXHAUST_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleBikeCustomChange({ exhaustStyle: opt.id })}
                  className={`px-2 py-1 rounded-md text-xs font-medium transition-colors ${
                    bikeCustom.exhaustStyle === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'bg-zinc-900 text-zinc-300 hover:text-white border border-white/5'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Paralamas */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Paralama Dianteiro</span>
            <div className="grid grid-cols-4 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              {FENDER_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleBikeCustomChange({ frontFender: opt.id })}
                  className={`py-1 rounded-md text-[11px] font-medium transition-colors ${
                    bikeCustom.frontFender === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Paralama Traseiro</span>
            <div className="grid grid-cols-4 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              {FENDER_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleBikeCustomChange({ rearFender: opt.id })}
                  className={`py-1 rounded-md text-[11px] font-medium transition-colors ${
                    bikeCustom.rearFender === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Retrovisores */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Retrovisores</span>
            <div className="grid grid-cols-2 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              {MIRROR_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleBikeCustomChange({ mirrors: opt.id })}
                  className={`py-1 rounded-md text-xs font-medium transition-colors ${
                    bikeCustom.mirrors === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Banco, Farol e Pinças */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-medium text-zinc-400">Banco</span>
              <div className="flex gap-1.5">
                {SEAT_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    title={opt.label}
                    onClick={() => handleBikeCustomChange({ seatColor: opt.id })}
                    className={`w-6 h-6 rounded-md border ${
                      bikeCustom.seatColor === opt.id
                        ? 'border-amber-400 ring-2 ring-amber-400/60'
                        : 'border-white/20'
                    }`}
                    style={{ backgroundColor: opt.hex }}
                  />
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-medium text-zinc-400">Farol / DRL</span>
              <div className="flex gap-1.5">
                {HEADLIGHT_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    title={opt.label}
                    onClick={() => handleBikeCustomChange({ headlightTint: opt.id })}
                    className={`w-6 h-6 rounded-md border ${
                      bikeCustom.headlightTint === opt.id
                        ? 'border-amber-400 ring-2 ring-amber-400/60'
                        : 'border-white/20'
                    }`}
                    style={{ backgroundColor: opt.hex }}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400">Pinças de Freio</span>
            <div className="flex gap-1.5">
              {CALIPER_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  title={opt.label}
                  onClick={() => handleBikeCustomChange({ caliperColor: opt.id })}
                  className={`w-6 h-6 rounded-md border ${
                    bikeCustom.caliperColor === opt.id
                      ? 'border-amber-400 ring-2 ring-amber-400/60'
                      : 'border-white/20'
                  }`}
                  style={{ backgroundColor: opt.hex }}
                />
              ))}
            </div>
          </div>

          {/* Gráficos & Reflexos no Mapa */}
          <div className="flex flex-col gap-1.5 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-medium text-zinc-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Reflexos no Mapa Todo</span>
              </span>
              <span className="text-[10px] text-zinc-400 font-mono-num">
                {reflectionsEnabled ? 'PBR + Poças + Espelho' : 'Desativado'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              <button
                type="button"
                onClick={() => {
                  if (!reflectionsEnabled) handleToggleReflections();
                }}
                className={`py-1.5 rounded-md text-xs font-medium transition-colors ${
                  reflectionsEnabled
                    ? 'bg-amber-500 text-zinc-950 font-semibold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Ligado
              </button>
              <button
                type="button"
                onClick={() => {
                  if (reflectionsEnabled) handleToggleReflections();
                }}
                className={`py-1.5 rounded-md text-xs font-medium transition-colors ${
                  !reflectionsEnabled
                    ? 'bg-amber-500 text-zinc-950 font-semibold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Desligado
              </button>
            </div>
            <p className="text-[10px] text-zinc-400 leading-snug">
              Ativa poças de água reflexivas no asfalto da favela, piso espelhado na quadra de futebol e brilho PBR nas carenagens e cromados da moto.
            </p>
          </div>

          {/* Reflexo Real no Chão (Espelho de Verdade) */}
          <div className="flex flex-col gap-1.5 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-medium text-zinc-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Reflexo Real no Chão (Espelho)</span>
              </span>
              <span className="text-[10px] text-zinc-400 font-mono-num">
                {realGroundReflections ? 'Ativo' : 'Desativado'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1 p-0.5 rounded-lg bg-zinc-900 border border-white/5">
              <button
                type="button"
                onClick={() => {
                  if (!realGroundReflections) handleToggleRealGroundReflections();
                }}
                className={`py-1.5 rounded-md text-xs font-medium transition-colors ${
                  realGroundReflections
                    ? 'bg-amber-500 text-zinc-950 font-semibold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Ligado
              </button>
              <button
                type="button"
                onClick={() => {
                  if (realGroundReflections) handleToggleRealGroundReflections();
                }}
                className={`py-1.5 rounded-md text-xs font-medium transition-colors ${
                  !realGroundReflections
                    ? 'bg-amber-500 text-zinc-950 font-semibold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Desligado
              </button>
            </div>
            <p className="text-[10px] text-zinc-400 leading-snug">
              Reflexo planar em tempo real nas poças, asfalto molhado, calçadas e quadra, espelhando a CG 160, o piloto, as casas, faíscas e o céu com efeito Fresnel.
            </p>
          </div>
        </aside>
      )}

      {/* Clean Loading Overlay */}
      {!loadProgress.loaded && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#0b0d11]/95 px-6">
          <div className="w-full max-w-md p-6 rounded-xl bg-[#12161f] border border-white/10 flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <h2 className="font-display text-2xl font-bold text-white">Grau Favela</h2>
              <p className="text-sm text-zinc-400">
                Simulador realista em 1ª pessoa com física estilo MX Bikes e molejo.
              </p>
            </div>

            {loadProgress.error ? (
              <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-sm text-red-200">
                {loadProgress.error}
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-xs text-zinc-300 font-mono-num">
                  <span>{loadProgress.statusText}</span>
                  <span>{loadProgress.percent}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-zinc-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 transition-[width] duration-150"
                    style={{ width: `${loadProgress.percent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
