import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AudioEngine } from './AudioEngine';
import { BikePhysics } from './BikePhysics';
import { BikeRig } from './BikeRig';
import { FavelaWorld } from './FavelaWorld';
import { IPhoneDevice } from './IPhoneDevice';
import { createProceduralTextures, ProceduralTextureSet } from './ProceduralTextures';
import { GroundHit, RoadTerrain, WORLD_HALF_EXTENT } from './RoadTerrain';
import {
  BikeCustomization,
  BikeModelId,
  CameraMode,
  ControlInputs,
  EmoteId,
  GloveStyle,
  GraphicsQuality,
  LoadProgress,
  PhysicsPreset,
  RiderState,
  ScreenStretchMode,
  TelemetryState,
} from './types';

function dampAngle(current: number, target: number, lambda: number, dt: number): number {
  const diff = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  return current + diff * (1 - Math.exp(-lambda * dt));
}

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class GameEngine {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene: THREE.Scene;
  private readonly camera: THREE.PerspectiveCamera;
  private readonly orbitControls: OrbitControls;
  private readonly isSoftwareGl: boolean;

  private readonly terrain: RoadTerrain;
  private readonly textures: ProceduralTextureSet;
  private readonly world: FavelaWorld;
  private readonly rig: BikeRig;
  private readonly physics: BikePhysics;
  private readonly iphone: IPhoneDevice;
  private readonly phoneLiveCamera = new THREE.PerspectiveCamera(60, 560 / 750, 0.06, 650);
  private readonly _phCamPos = new THREE.Vector3();
  private readonly _phCamRight = new THREE.Vector3();
  private readonly _phCamUp = new THREE.Vector3();
  private readonly _phCamFwd = new THREE.Vector3();
  private readonly _phCamLook = new THREE.Vector3();
  public readonly audio = new AudioEngine();

  public bikeModel: BikeModelId = 'cg_160';
  public cameraMode: CameraMode = 'first_person';
  public graphicsQuality: GraphicsQuality = 'high';
  public screenStretch = 1.35;
  public molejoMultiplier = 1.0;
  public fpFov = 78;
  public reflectionsEnabled = true;
  public realGroundReflectionsEnabled = true;
  private readonly studioEnv: THREE.Texture;
  private readonly outdoorSkyEnv: THREE.Texture;
  private resizeObserver: ResizeObserver | null = null;

  private readonly keys = new Set<string>();
  private readonly virtualInputs: Partial<ControlInputs> = {};
  private readonly inputs: ControlInputs = {
    throttle: 0,
    frontBrake: 0,
    rearBrake: 0,
    steer: 0,
    riderPitch: 0,
    molejo: 0,
    clutch: false,
    noHand: false,
    burnout: false,
  };

  private frameId = 0;
  private disposed = false;
  private lastTime = performance.now();
  private hudTimer = 0;

  // Camera smoothing state & scratch vectors (zero per-frame GC)
  private readonly camPos = new THREE.Vector3();
  private readonly camLook = new THREE.Vector3();
  private camYaw = 0;
  private readonly _v1 = new THREE.Vector3();
  private readonly _v2 = new THREE.Vector3();
  private readonly _v3 = new THREE.Vector3();
  private readonly _q1 = new THREE.Quaternion();
  private readonly _m1 = new THREE.Matrix4();
  private readonly _up = new THREE.Vector3(0, 1, 0);

  // First-person helmet look offset & MX Bikes neck suspension inertia
  private fpCamYaw = 0;
  private fpLookYaw = 0;
  private fpLookPitch = 0;
  private fpHeadPitchLag = 0;
  private fpHeadBackLag = 0;
  private fpHeadDropLag = 0;
  private camEffectTime = 0;
  private smoothThrottleEffect = 0;
  private smoothAccelG = 0;
  private prevSpeedMs = 0;
  private pointerLocked = false;
  private virtualCamLookX = 0;
  private virtualCamLookY = 0;
  private chaseLookYawOffset = 0;
  private chaseLookPitchOffset = 0;
  private prevVirtualJump = false;

  // Dismount / On-Foot state
  public riderState: RiderState = 'mounted';
  private transitionT = 0;
  private approachingMount = false;
  private mountApproachTimer = 0;
  private virtualStickY = 0;
  private readonly onFootPos = new THREE.Vector3();
  private readonly onFootVel = new THREE.Vector3();
  private onFootYaw = 0;
  private onFootTurnVel = 0;
  private onFootDirSign = 1;
  private onFootVertVel = 0;
  private onFootAirborne = false;
  private walkPhase = 0;
  private dismountHint = '';
  private dismountHintTimer = 0;
  private timedEmote: EmoteId = 'none';
  private timedEmoteTimer = 0;
  private emoteHoldActive = false;
  private emoteDragX = 0;
  private emoteDragY = 0;
  private smoothEmoteDragX = 0;
  private smoothEmoteDragY = 0;
  private heldEmoteKey: string | null = null;
  private heldEmoteKeyDownTime = 0;
  private canvasDraggingEmote = false;

  // 3D iPhone state & raycaster
  public isPhoneOpen = false;
  private phoneBlend = 0;
  private draggingPhoneScreen = false;
  private phoneLastNx = 0.5;
  private phoneLastNy = 0.5;
  private readonly raycaster = new THREE.Raycaster();
  private readonly pointerNdc = new THREE.Vector2();
  private readonly footHit: GroundHit = {
    height: 0,
    nx: 0,
    ny: 1,
    nz: 0,
    surface: 'asphalt',
  };

  constructor(
    private readonly container: HTMLElement,
    private readonly onLoadProgress: (p: LoadProgress) => void,
    private readonly onTelemetry: (t: TelemetryState) => void
  ) {
    this.isSoftwareGl = detectSoftwareGl();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.5));
    this.renderer.shadowMap.enabled = false;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    this.terrain = new RoadTerrain();
    const maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();
    this.textures = createProceduralTextures(
      maxAnisotropy,
      this.renderer.capabilities.maxTextureSize
    );

    // Studio & Photorealistic 360-degree Brazilian golden-hour sky reflection environments
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.studioEnv = pmrem.fromScene(envScene, 0.035).texture;
    envScene.dispose();

    this.outdoorSkyEnv = pmrem.fromEquirectangular(this.textures.skyMap).texture;
    pmrem.dispose();

    this.scene.environment = this.reflectionsEnabled ? this.outdoorSkyEnv : this.studioEnv;
    this.scene.environmentIntensity = this.reflectionsEnabled ? 1.45 : 0.60;

    const aspect = container.clientWidth / Math.max(1, container.clientHeight) / this.screenStretch;
    this.camera = new THREE.PerspectiveCamera(78, aspect, 0.05, 1450);

    this.orbitControls = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbitControls.enabled = false;
    this.orbitControls.enableDamping = !this.isSoftwareGl;
    this.orbitControls.dampingFactor = 0.07;

    this.world = new FavelaWorld(this.scene, this.terrain, this.textures, this.isSoftwareGl);
    this.rig = new BikeRig(this.scene, this.textures, maxAnisotropy);
    this.iphone = new IPhoneDevice(this.scene, maxAnisotropy);
    this.physics = new BikePhysics(this.terrain);
    this.fpCamYaw = this.physics.yaw;
    this.setGraphicsQuality(this.isSoftwareGl ? 'medium' : 'high');

    // Initialize camera near spawn
    this.camPos.copy(this.physics.pos).add(new THREE.Vector3(-4, 2.2, 0));
    this.camLook.copy(this.physics.pos).add(new THREE.Vector3(6, 1.0, 0));

    this.bindEvents();
    void this.initAssets();
  }

  private async initAssets(): Promise<void> {
    try {
      let housesDone = false;
      const housesPromise = this.world.loadHouses(this.terrain, this.textures).then(() => {
        housesDone = true;
      });
      const modelsPromise = Promise.all([
        this.rig.loadModels((percent, statusText) => {
          if (!this.disposed) {
            this.onLoadProgress({
              loaded: false,
              percent: housesDone ? Math.max(percent, 96) : percent,
              statusText,
              error: null,
            });
          }
        }),
        this.iphone.loadModel(),
      ]);

      await modelsPromise;
      if (!housesDone && !this.disposed) {
        this.onLoadProgress({
          loaded: false,
          percent: 96,
          statusText: 'Montando casas e pista da favela...',
          error: null,
        });
      }
      await housesPromise;

      if (this.disposed) return;

      this.physics.setBikeModel(this.bikeModel);
      this.rig.setBikeModel(this.bikeModel);
      this.rig.update(this.physics, this.cameraMode === 'first_person');
      this.rig.updateHelmet(0, this.camera, this.cameraMode === 'first_person', false, 0, false, 0);
      if (!this.isSoftwareGl) {
        this.renderer.compile(this.scene, this.camera);
      }

      this.onLoadProgress({
        loaded: true,
        percent: 100,
        statusText: 'Pronto pro grau!',
        error: null,
      });

      this.lastTime = performance.now();
      this.scheduleNextFrame();
    } catch (err) {
      if (!this.disposed) {
        this.onLoadProgress({
          loaded: false,
          percent: 0,
          statusText: 'Falha ao carregar modelos 3D',
          error: err instanceof Error ? err.message : 'Erro desconhecido',
        });
      }
    }
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.handleResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.handleResize());
      this.resizeObserver.observe(this.container);
    }
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.addEventListener('pointerdown', this.handlePointerDown);
    this.renderer.domElement.addEventListener('pointermove', this.handlePointerMove);
    window.addEventListener('pointerup', this.handlePointerUp);
    window.addEventListener('pointercancel', this.handlePointerUp);
    this.renderer.domElement.addEventListener('wheel', this.handleWheel, { passive: false });
    this.renderer.domElement.addEventListener('mousemove', this.handleMouseMove);
    this.renderer.domElement.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mouseup', this.handleMouseUp);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
  }

  private handleResize = (): void => {
    if (this.disposed) return;
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h / this.screenStretch;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public setScreenStretchMode(mode: ScreenStretchMode): void {
    this.screenStretch = mode === 'ultra' ? 1.6 : mode === 'stretched' ? 1.35 : 1.0;
    this.handleResize();
  }

  private handleKeyDown = (e: KeyboardEvent): void => {
    if (e.repeat) return;
    this.audio.start();

    const code = e.code;
    this.keys.add(code);

    if (code === 'KeyR') {
      this.resetBike();
    } else if (code === 'KeyK') {
      this.toggleHelmet();
    } else if (code === 'KeyP') {
      this.togglePhone();
    } else if (code === 'Escape') {
      if (this.isPhoneOpen) {
        if (!this.iphone.handleBackAction()) {
          this.isPhoneOpen = false;
        }
      }
    } else if (code === 'KeyU' || code === 'Enter') {
      if (code === 'Enter') e.preventDefault();
      this.toggleDismount();
    } else if (code === 'KeyV') {
      this.cycleCameraMode();
    } else if (code === 'KeyG') {
      this.physics.autoGear = !this.physics.autoGear;
    } else if (code === 'KeyQ') {
      this.physics.shiftDown();
    } else if (code === 'KeyE') {
      if (!this.physics.autoGear) this.physics.shiftUp();
    } else if (code === 'PageUp') {
      this.physics.shiftUp();
    } else if (code === 'PageDown') {
      this.physics.shiftDown();
    } else if (
      code === 'Digit1' ||
      code === 'Digit2' ||
      code === 'Digit3' ||
      code === 'Digit4' ||
      code === 'Digit5' ||
      code === 'Digit6' ||
      code === 'Digit7'
    ) {
      const map: Record<string, EmoteId> = {
        Digit1: 'salve',
        Digit2: 'hang_loose',
        Digit3: 'salute',
        Digit4: 'flex',
        Digit5: 'celebrate',
        Digit6: 'clap',
        Digit7: 'middle_finger',
      };
      this.heldEmoteKey = code;
      this.heldEmoteKeyDownTime = performance.now();
      this.startHoldEmote(map[code], this.emoteDragX, this.emoteDragY);
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
    if (this.heldEmoteKey === e.code) {
      const elapsed = performance.now() - this.heldEmoteKeyDownTime;
      this.heldEmoteKey = null;
      // Hold >= 240ms lowers arm on release; quick tap keeps gesture up briefly (~3.4s)
      this.stopHoldEmote(elapsed < 240, 3.4);
    }
  };

  private raycastPhoneScreen(clientX: number, clientY: number): { nx: number; ny: number } | null {
    if (!this.isPhoneOpen || this.phoneBlend < 0.55 || !this.iphone.screenMesh || !this.iphone.root.visible) {
      return null;
    }
    const rect = this.renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;
    this.pointerNdc.set(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -(((clientY - rect.top) / rect.height) * 2 - 1)
    );
    this.raycaster.setFromCamera(this.pointerNdc, this.camera);
    const hits = this.raycaster.intersectObject(this.iphone.screenMesh, false);
    if (hits.length > 0 && hits[0].uv) {
      return {
        nx: THREE.MathUtils.clamp(hits[0].uv.x, 0, 1),
        ny: THREE.MathUtils.clamp(1 - hits[0].uv.y, 0, 1),
      };
    }
    return null;
  }

  private handlePointerDown = (e: PointerEvent): void => {
    this.audio.start();
    const uv = this.raycastPhoneScreen(e.clientX, e.clientY);
    if (uv) {
      this.draggingPhoneScreen = true;
      this.phoneLastNx = uv.nx;
      this.phoneLastNy = uv.ny;
      if (this.cameraMode === 'free_orbit') {
        this.orbitControls.enabled = false;
      }
      this.iphone.onPointerDown(uv.nx, uv.ny);
      e.stopPropagation();
    }
  };

  private handlePointerMove = (e: PointerEvent): void => {
    const uv = this.raycastPhoneScreen(e.clientX, e.clientY);
    if (this.draggingPhoneScreen) {
      if (uv) {
        this.phoneLastNx = uv.nx;
        this.phoneLastNy = uv.ny;
      }
      this.iphone.onPointerMove(uv ? uv.nx : this.phoneLastNx, uv ? uv.ny : this.phoneLastNy);
      return;
    }
    if (uv) {
      const interactive = this.iphone.isHoveringInteractive(uv.nx, uv.ny);
      this.renderer.domElement.style.cursor = interactive ? 'pointer' : 'default';
    } else if (this.renderer.domElement.style.cursor !== '') {
      this.renderer.domElement.style.cursor = '';
    }
  };

  private handlePointerUp = (e: PointerEvent): void => {
    if (!this.draggingPhoneScreen) return;
    const uv = this.raycastPhoneScreen(e.clientX, e.clientY);
    this.iphone.onPointerUp(uv ? uv.nx : this.phoneLastNx, uv ? uv.ny : this.phoneLastNy);
    this.draggingPhoneScreen = false;
    if (this.cameraMode === 'free_orbit') {
      this.orbitControls.enabled = true;
    }
  };

  private handleWheel = (e: WheelEvent): void => {
    const uv = this.raycastPhoneScreen(e.clientX, e.clientY);
    if (uv) {
      e.preventDefault();
      e.stopPropagation();
      this.iphone.onWheel(e.deltaY);
    }
  };

  private handleMouseDown = (e: MouseEvent): void => {
    this.audio.start();
    if (this.draggingPhoneScreen) return;
    if (e.button === 0 && this.isEmoteActive()) {
      this.canvasDraggingEmote = true;
      if (this.cameraMode === 'free_orbit') {
        this.orbitControls.enabled = false;
      }
      this.updateEmoteDragFromClient(e.clientX, e.clientY);
    }
  };

  private handleMouseUp = (): void => {
    if (this.canvasDraggingEmote) {
      this.canvasDraggingEmote = false;
      if (this.cameraMode === 'free_orbit' && !this.draggingPhoneScreen) {
        this.orbitControls.enabled = true;
      }
    }
  };

  private updateEmoteDragFromClient(clientX: number, clientY: number): void {
    const rect = this.renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const nx = ((clientX - rect.left) / rect.width) * 2 - 1;
    const ny = -(((clientY - rect.top) / rect.height) * 2 - 1);
    this.moveEmoteDrag(nx, ny);
  }

  private handleMouseMove = (e: MouseEvent): void => {
    if (this.draggingPhoneScreen) return;
    if ((e.buttons & 1) && (this.canvasDraggingEmote || this.isEmoteActive())) {
      this.canvasDraggingEmote = true;
      this.updateEmoteDragFromClient(e.clientX, e.clientY);
      return;
    }
    if (this.cameraMode === 'first_person' && (e.buttons & 1 || this.pointerLocked)) {
      if (this.riderState === 'on_foot' && !this.approachingMount) {
        this.onFootYaw -= e.movementX * 0.0030;
        this.fpLookPitch = THREE.MathUtils.clamp(
          this.fpLookPitch - e.movementY * 0.0025,
          -1.30,
          1.15
        );
      } else {
        this.fpLookYaw = THREE.MathUtils.clamp(this.fpLookYaw - e.movementX * 0.0028, -1.35, 1.35);
        this.fpLookPitch = THREE.MathUtils.clamp(
          this.fpLookPitch - e.movementY * 0.0024,
          -0.55,
          0.55
        );
      }
    }
  };

  private handlePointerLockChange = (): void => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
  };

  public setCameraMode(mode: CameraMode): void {
    this.cameraMode = mode;
    this.rig.setFirstPersonMode(mode === 'first_person', this.riderState === 'on_foot');
    this.orbitControls.enabled = mode === 'free_orbit';
    if (mode === 'free_orbit') {
      const target = this.riderState === 'on_foot' ? this.onFootPos : this.physics.pos;
      this.orbitControls.target.copy(target).add(new THREE.Vector3(0, 0.9, 0));
      this.camera.position.copy(target).add(new THREE.Vector3(-3.2, 1.9, 2.4));
      this.orbitControls.update();
    }
    this.fpCamYaw = this.riderState === 'on_foot' ? this.onFootYaw : this.physics.yaw;
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
  }

  public cycleCameraMode(): CameraMode {
    const order: CameraMode[] = ['first_person', 'third_person', 'moto_vlog', 'free_orbit'];
    const next = order[(order.indexOf(this.cameraMode) + 1) % order.length];
    this.setCameraMode(next);
    return next;
  }

  public setPhysicsPreset(preset: PhysicsPreset): void {
    this.physics.preset = preset;
  }

  public setAutoGear(auto: boolean): void {
    this.physics.autoGear = auto;
  }

  public setFirstPersonConfig(fov: number, distance: number): void {
    this.fpFov = THREE.MathUtils.clamp(fov, 60, 120);
    this.rig.fpCamDistance = THREE.MathUtils.clamp(distance, -0.22, 0.28);
  }

  public setGloveStyle(style: GloveStyle): void {
    this.rig.setGloveStyle(style);
  }

  public setBikeCustomization(custom: BikeCustomization): void {
    this.rig.setCustomization(custom);
  }

  public setBikeModel(model: BikeModelId): void {
    this.bikeModel = model;
    this.physics.setBikeModel(model);
    this.rig.setBikeModel(model);
    if (this.riderState === 'mounted') {
      this.rig.update(this.physics, this.cameraMode === 'first_person', 0, this.inputs);
    }
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.graphicsQuality = quality;
    const dpr = window.devicePixelRatio || 1;
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();

    let pixelRatio = Math.min(dpr, 1.5);
    let camFar = 1450;
    let fogDensity = 0.0014;
    let envIntensity = 1.05;
    let exposure = 1.08;
    let aniso = Math.min(8, maxAniso);

    if (quality === 'low') {
      pixelRatio = this.isSoftwareGl ? 0.75 : Math.min(dpr, 0.9);
      camFar = 520;
      fogDensity = 0.0029;
      envIntensity = 0.65;
      exposure = 1.04;
      aniso = 1;
    } else if (quality === 'medium') {
      pixelRatio = this.isSoftwareGl ? 1.0 : Math.min(dpr, 1.15);
      camFar = 850;
      fogDensity = 0.0020;
      envIntensity = 0.88;
      exposure = 1.06;
      aniso = Math.min(4, maxAniso);
    } else if (quality === 'ultra') {
      pixelRatio = this.isSoftwareGl ? 1.0 : Math.min(dpr, 2.0);
      camFar = 2000;
      fogDensity = 0.00095;
      envIntensity = 1.24;
      exposure = 1.12;
      aniso = maxAniso;
    }

    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.toneMappingExposure = exposure;
    this.scene.environmentIntensity = envIntensity;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.density = fogDensity;
    }
    this.camera.far = camFar;
    this.camera.updateProjectionMatrix();

    const texList = [
      this.textures.asphaltMap,
      this.textures.asphaltRoughness,
      this.textures.brickMap,
      this.textures.concreteMap,
      this.textures.roofMap,
      this.textures.gloveMap,
      this.textures.skyMap,
      this.textures.carbonMap,
      this.textures.signLombadaMap,
    ];
    for (const tex of texList) {
      if (tex.anisotropy !== aniso) {
        tex.anisotropy = aniso;
        tex.needsUpdate = true;
      }
    }

    this.world.setReflectionQuality(quality);
    this.iphone.setGraphicsQuality(quality);
    this.handleResize();
  }

  public setReflectionsEnabled(enabled: boolean): void {
    this.reflectionsEnabled = enabled;
    this.scene.environment = enabled ? this.outdoorSkyEnv : this.studioEnv;
    this.scene.environmentIntensity = enabled ? 1.45 : 0.60;
    this.world.setReflectionsEnabled(enabled);
    this.rig.setReflectionsEnabled(enabled);
    this.iphone.setReflectionsEnabled(enabled);
  }

  public togglePhone(): boolean {
    if (this.physics.crashed) {
      this.setHint('Volte na pista antes de pegar o iPhone');
      return false;
    }
    if (this.riderState === 'mounted') {
      const speedKmh = Math.hypot(this.physics.vel.x, this.physics.vel.z) * 3.6;
      if (!this.isPhoneOpen && speedKmh > 28) {
        this.setHint('Reduza abaixo de 28 km/h para usar o iPhone');
        return false;
      }
    }
    this.isPhoneOpen = !this.isPhoneOpen;
    if (this.isPhoneOpen) {
      this.timedEmote = 'none';
      this.timedEmoteTimer = 0;
      this.emoteHoldActive = false;
      this.virtualInputs.emote = 'none';
    } else {
      this.draggingPhoneScreen = false;
    }
    return this.isPhoneOpen;
  }

  public toggleHelmet(): boolean {
    if (this.physics.crashed) {
      this.setHint('Volte na pista antes de mexer no capacete');
      return this.rig.isHelmetOn();
    }
    if (this.riderState === 'dismounting' || this.riderState === 'mounting') {
      return this.rig.isHelmetOn();
    }
    if (this.riderState === 'mounted') {
      const speedKmh = Math.hypot(this.physics.vel.x, this.physics.vel.z) * 3.6;
      if (speedKmh > 35) {
        this.setHint('Reduza abaixo de 35 km/h para tirar/colocar o capacete');
        return this.rig.isHelmetOn();
      }
    }
    const nextOn = !this.rig.isHelmetOn();
    this.rig.setHelmetOn(nextOn);
    this.isPhoneOpen = false;
    this.draggingPhoneScreen = false;
    this.timedEmote = 'none';
    this.timedEmoteTimer = 0;
    this.emoteHoldActive = false;
    this.virtualInputs.emote = 'none';
    return nextOn;
  }

  public setRealGroundReflectionEnabled(enabled: boolean): void {
    this.realGroundReflectionsEnabled = enabled;
    this.world.setRealGroundReflectionEnabled(enabled);
  }

  public setVirtualInput<K extends keyof ControlInputs>(key: K, val: ControlInputs[K]): void {
    this.virtualInputs[key] = val;
  }

  public setVirtualStickY(y: number): void {
    this.virtualStickY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public setVirtualCameraLook(x: number, y: number): void {
    this.virtualCamLookX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualCamLookY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public resetCameraLook(): void {
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
    this.chaseLookYawOffset = 0;
    this.chaseLookPitchOffset = 0;
    if (this.cameraMode === 'free_orbit') {
      const target = this.riderState === 'on_foot' ? this.onFootPos : this.physics.pos;
      this.orbitControls.target.copy(target).add(new THREE.Vector3(0, 0.9, 0));
      this.camera.position.copy(target).add(new THREE.Vector3(-3.2, 1.9, 2.4));
      this.orbitControls.update();
    }
  }

  public shiftUp(): void {
    this.physics.shiftUp();
  }

  public shiftDown(): void {
    this.physics.shiftDown();
  }

  public triggerEmote(emote: EmoteId, durationS = 3.2): void {
    this.emoteHoldActive = false;
    if (emote === 'none' || (this.timedEmote === emote && this.timedEmoteTimer > 0.1)) {
      this.timedEmote = 'none';
      this.timedEmoteTimer = 0;
      return;
    }
    this.timedEmote = emote;
    this.timedEmoteTimer = durationS;
  }

  public startHoldEmote(emote: EmoteId, nx = 0, ny = 0): void {
    if (emote === 'none') {
      this.stopHoldEmote(false);
      return;
    }
    this.timedEmote = emote;
    this.timedEmoteTimer = 0;
    this.emoteHoldActive = true;
    this.emoteDragX = THREE.MathUtils.clamp(nx, -1, 1);
    this.emoteDragY = THREE.MathUtils.clamp(ny, -1, 1);
  }

  public moveEmoteDrag(nx: number, ny: number): void {
    this.emoteDragX = THREE.MathUtils.clamp(nx, -1, 1);
    this.emoteDragY = THREE.MathUtils.clamp(ny, -1, 1);
  }

  public stopHoldEmote(keepBrief = false, briefDurationS = 3.4): void {
    this.emoteHoldActive = false;
    if (keepBrief && this.timedEmote !== 'none') {
      this.timedEmoteTimer = briefDurationS;
    } else {
      this.timedEmote = 'none';
      this.timedEmoteTimer = 0;
      this.virtualInputs.emote = 'none';
    }
  }

  public isEmoteActive(): boolean {
    return (
      this.emoteHoldActive ||
      this.timedEmote !== 'none' ||
      this.inputs.noHand ||
      Boolean(this.inputs.emote && this.inputs.emote !== 'none')
    );
  }

  private setHint(msg: string): void {
    this.dismountHint = msg;
    this.dismountHintTimer = 2.6;
  }

  public toggleDismount(): void {
    if (this.physics.crashed) {
      this.resetBike();
      return;
    }
    if (this.riderState === 'mounted') {
      const speedKmh = Math.hypot(this.physics.vel.x, this.physics.vel.z) * 3.6;
      if (speedKmh > 35) {
        this.setHint('Reduza abaixo de 35 km/h para descer');
        return;
      }
      this.approachingMount = false;
      this.riderState = 'dismounting';
      this.transitionT = 0;
      this.dismountHint = '';
    } else if (this.riderState === 'on_foot') {
      const dist = Math.hypot(
        this.onFootPos.x - this.physics.pos.x,
        this.onFootPos.z - this.physics.pos.z
      );
      if (dist > 4.2) {
        this.setHint('Chegue perto da moto para subir (ou R)');
        return;
      }
      this.rig.getLeftStandWorldPos(this._v1);
      const standDist = Math.hypot(this.onFootPos.x - this._v1.x, this.onFootPos.z - this._v1.z);
      const yawDiff = Math.abs(
        Math.atan2(
          Math.sin(this.physics.yaw - this.onFootYaw),
          Math.cos(this.physics.yaw - this.onFootYaw)
        )
      );
      this.approachingMount = standDist > 0.30 || yawDiff > 0.65;
      this.mountApproachTimer = 0;
      this.riderState = 'mounting';
      this.transitionT = 1;
      this.dismountHint = '';
    } else if (this.riderState === 'dismounting') {
      this.approachingMount = false;
      this.riderState = 'mounting';
    } else if (this.riderState === 'mounting') {
      if (this.approachingMount) {
        this.approachingMount = false;
        this.riderState = 'on_foot';
      } else {
        this.riderState = 'dismounting';
      }
    }
  }

  public resetBike(): void {
    this.physics.reset();
    this.riderState = 'mounted';
    this.transitionT = 0;
    this.approachingMount = false;
    this.mountApproachTimer = 0;
    this.onFootTurnVel = 0;
    this.onFootDirSign = 1;
    this.virtualStickY = 0;
    this.rig.attachRiderToBike(true);
    this.camYaw = this.physics.yaw;
    this.fpCamYaw = this.physics.yaw;
    this.dismountHint = '';
    this.dismountHintTimer = 0;
    this.fpLookYaw = 0;
    this.fpLookPitch = 0;
    this.fpHeadPitchLag = 0;
    this.fpHeadBackLag = 0;
    this.fpHeadDropLag = 0;
    this.smoothThrottleEffect = 0;
    this.smoothAccelG = 0;
    this.prevSpeedMs = 0;
  }

  private gatherInputs(dt: number): void {
    const has = (c: string) => this.keys.has(c);

    // Throttle: W / ArrowUp
    const kThrottle = has('KeyW') || has('ArrowUp') ? 1 : 0;
    // Front Brake / Reverse: S / ArrowDown (Note: ArrowDown / Shift+S also pulls rider back!)
    const kFrontBrake = has('KeyS') ? 1 : 0;
    // Rear Brake ("Freio no Pé" for Grau): Space or C
    const kRearBrake = has('Space') || has('KeyC') ? 1 : 0;
    // Steer: A/D or Left/Right
    const kSteer = (has('KeyD') || has('ArrowRight') ? 1 : 0) - (has('KeyA') || has('ArrowLeft') ? 1 : 0);
    // Rider Pitch (Pull Grau / Tuck):
    // ArrowDown or ControlLeft or S+Shift or dedicated Down = Pull back (puxar grau)!
    // Wait: let's make W + Shift/Ctrl OR ArrowDown / KeyX pull back, AND smartly:
    // If holding W (throttle) + ArrowDown / ShiftLeft / KeyF? Wait—let's make keyboard controls super intuitive!
    // - W / ArrowUp = Acelerar (segurar W também inclina levemente pra frente em alta velocidade, ou Ctrl = Carena / Tuck)
    // - ArrowDown / KeyX / ShiftLeft = Puxar o Grau (corpo pra trás!) + Embreagem Kick se Shift
    // - Space / KeyC = Freio Traseiro (Freio no Pé - segura o grau no ponto!)
    // - KeyS = Freio Dianteiro / RL
    // - KeyZ / KeyB = Molejo extra esquerda/direita
    // - KeyE (auto) or KeyF = Grau Sem Mão / Salve!
    const pullGrauKey = has('ArrowDown') || has('KeyX') || has('ShiftRight') ? 1 : 0;
    const tuckKey = has('ControlLeft') || has('KeyT') ? 1 : 0;
    const kRiderPitch = pullGrauKey - tuckKey;

    const kMolejo =
      ((has('KeyB') ? 1 : 0) - (has('KeyZ') ? 1 : 0)) * this.molejoMultiplier +
      kSteer * 0.35 * this.molejoMultiplier;

    const kClutch = has('ShiftLeft');
    const kNoHand = has('KeyF') || (this.physics.autoGear && has('KeyE'));
    const kBurnout = has('KeyS') && has('KeyW');

    this.inputs.throttle = Math.max(kThrottle, this.virtualInputs.throttle ?? 0);
    this.inputs.frontBrake = Math.max(kFrontBrake, this.virtualInputs.frontBrake ?? 0);
    this.inputs.rearBrake = Math.max(kRearBrake, this.virtualInputs.rearBrake ?? 0);

    const targetSteer = Math.abs(this.virtualInputs.steer ?? 0) > 0.05 ? this.virtualInputs.steer! : kSteer;
    this.inputs.steer = THREE.MathUtils.damp(this.inputs.steer, targetSteer, 15, dt);

    const targetPitch =
      Math.abs(this.virtualInputs.riderPitch ?? 0) > 0.05
        ? this.virtualInputs.riderPitch!
        : kRiderPitch;
    this.inputs.riderPitch = THREE.MathUtils.damp(this.inputs.riderPitch, targetPitch, 10, dt);

    const targetMolejo =
      Math.abs(this.virtualInputs.molejo ?? 0) > 0.05
        ? this.virtualInputs.molejo!
        : ((has('KeyB') ? 1 : 0) - (has('KeyZ') ? 1 : 0)) * this.molejoMultiplier;
    this.inputs.molejo = THREE.MathUtils.damp(this.inputs.molejo, targetMolejo, 10, dt);

    this.inputs.clutch = kClutch || Boolean(this.virtualInputs.clutch);
    this.inputs.noHand = kNoHand || Boolean(this.virtualInputs.noHand);
    this.inputs.burnout = kBurnout || Boolean(this.virtualInputs.burnout);
    this.inputs.emote =
      this.timedEmote !== 'none'
        ? this.timedEmote
        : this.inputs.noHand
          ? this.virtualInputs.emote && this.virtualInputs.emote !== 'none'
            ? this.virtualInputs.emote
            : 'salve'
          : 'none';
  }

  private resolveOnFootBikeCollision(): void {
    // Oriented rounded-box keep-out around parked CG 160 so rider can stand snugly next to saddle without clipping tires
    const dx = this.onFootPos.x - this.physics.pos.x;
    const dz = this.onFootPos.z - this.physics.pos.z;
    const cosY = Math.cos(this.physics.yaw);
    const sinY = Math.sin(this.physics.yaw);
    // Project into bike frame (+X forward, +Z right)
    const localX = dx * cosY - dz * sinY;
    const localZ = dx * sinY + dz * cosY;

    const halfLen = 0.94;
    const halfWidth = 0.38;
    const clampedX = THREE.MathUtils.clamp(localX, -halfLen, halfLen);
    const clampedZ = THREE.MathUtils.clamp(localZ, -halfWidth, halfWidth);
    const penX = localX - clampedX;
    const penZ = localZ - clampedZ;
    if (Math.abs(penX) < 1e-4 && Math.abs(penZ) < 1e-4) {
      // Inside box: push out along nearest edge
      const distSide = halfWidth - Math.abs(localZ);
      const distEnd = halfLen - Math.abs(localX);
      let outX = localX;
      let outZ = localZ;
      if (distSide <= distEnd) {
        outZ = (localZ >= 0 ? 1 : -1) * halfWidth;
      } else {
        outX = (localX >= 0 ? 1 : -1) * halfLen;
      }
      this.onFootPos.x = this.physics.pos.x + outX * cosY + outZ * sinY;
      this.onFootPos.z = this.physics.pos.z - outX * sinY + outZ * cosY;
    }
  }

  private stepMountApproach(dt: number): void {
    this.mountApproachTimer += dt;
    this.rig.getLeftStandWorldPos(this._v1);

    // Check if rider is on the right side of the bike; if so, route cleanly around the rear tail first
    const dx = this.onFootPos.x - this.physics.pos.x;
    const dz = this.onFootPos.z - this.physics.pos.z;
    const cosY = Math.cos(this.physics.yaw);
    const sinY = Math.sin(this.physics.yaw);
    const localX = dx * cosY - dz * sinY;
    const localZ = dx * sinY + dz * cosY;

    let targetX = this._v1.x;
    let targetZ = this._v1.z;
    if (localZ > -0.18 && Math.abs(localX) < 1.05 && this.mountApproachTimer < 0.85) {
      const wpLocalX = -1.18;
      const wpLocalZ = -0.58;
      targetX = this.physics.pos.x + wpLocalX * cosY + wpLocalZ * sinY;
      targetZ = this.physics.pos.z - wpLocalX * sinY + wpLocalZ * cosY;
    }

    const toTargetX = targetX - this.onFootPos.x;
    const toTargetZ = targetZ - this.onFootPos.z;
    const toTargetDist = Math.hypot(toTargetX, toTargetZ);

    const standDist = Math.hypot(this._v1.x - this.onFootPos.x, this._v1.z - this.onFootPos.z);
    const desiredYaw =
      standDist > 0.38
        ? Math.atan2(-toTargetZ, toTargetX)
        : this.physics.yaw;

    const prevYaw = this.onFootYaw;
    this.onFootYaw = dampAngle(this.onFootYaw, desiredYaw, 11, dt);
    this.onFootTurnVel = dt > 1e-4 ? Math.atan2(Math.sin(prevYaw - this.onFootYaw), Math.cos(prevYaw - this.onFootYaw)) / dt : 0;

    const moveSpeed = standDist > 0.45 ? 4.4 : 2.6;
    if (toTargetDist > 0.04) {
      const step = Math.min(toTargetDist, moveSpeed * dt);
      const vx = (toTargetX / toTargetDist) * (step / Math.max(dt, 1e-4));
      const vz = (toTargetZ / toTargetDist) * (step / Math.max(dt, 1e-4));
      this.onFootVel.x = THREE.MathUtils.damp(this.onFootVel.x, vx, 16, dt);
      this.onFootVel.z = THREE.MathUtils.damp(this.onFootVel.z, vz, 16, dt);
      this.onFootPos.x += this.onFootVel.x * dt;
      this.onFootPos.z += this.onFootVel.z * dt;
    } else {
      this.onFootVel.set(0, 0, 0);
    }

    this.resolveOnFootBikeCollision();
    this.terrain.sampleGround(this.onFootPos.x, this.onFootPos.z, this.footHit);
    this.onFootPos.y = THREE.MathUtils.damp(this.onFootPos.y, this.footHit.height, 26, dt);

    const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
    if (horizSpeed > 0.15) {
      this.walkPhase += horizSpeed * 2.3 * dt;
    }

    const finalStandDist = Math.hypot(this._v1.x - this.onFootPos.x, this._v1.z - this.onFootPos.z);
    const finalYawDiff = Math.abs(
      Math.atan2(Math.sin(this.physics.yaw - this.onFootYaw), Math.cos(this.physics.yaw - this.onFootYaw))
    );
    if ((finalStandDist < 0.14 && finalYawDiff < 0.24) || this.mountApproachTimer > 1.25) {
      this.onFootPos.set(this._v1.x, this.footHit.height, this._v1.z);
      this.onFootYaw = this.physics.yaw;
      this.onFootVel.set(0, 0, 0);
      this.onFootTurnVel = 0;
      this.approachingMount = false;
    }
  }

  private stepOnFoot(dt: number): void {
    const has = (c: string) => this.keys.has(c);
    const vPitch = this.virtualInputs.riderPitch ?? 0;
    const vThrottle = this.virtualInputs.throttle ?? 0;
    const vFrontBrake = this.virtualInputs.frontBrake ?? 0;
    const vSteer = this.virtualInputs.steer ?? 0;

    const fwdKey = has('KeyW') || has('ArrowUp') ? 1 : 0;
    const backKey = has('KeyS') || has('ArrowDown') ? 1 : 0;
    let moveFwd = fwdKey - backKey;

    if (moveFwd === 0) {
      if (vThrottle > 0.15) moveFwd += vThrottle;
      if (vFrontBrake > 0.15) moveFwd -= vFrontBrake;
    }
    if (moveFwd === 0 && Math.abs(this.virtualStickY) > 0.16) {
      const mag = (Math.abs(this.virtualStickY) - 0.16) / 0.84;
      moveFwd = -Math.sign(this.virtualStickY) * mag;
    } else if (moveFwd === 0 && Math.abs(vPitch) > 0.15) {
      moveFwd = -vPitch;
    }
    moveFwd = THREE.MathUtils.clamp(moveFwd, -1, 1);

    const turnKey =
      (has('KeyD') || has('ArrowRight') ? 1 : 0) - (has('KeyA') || has('ArrowLeft') ? 1 : 0);
    const turn = Math.abs(vSteer) > 0.08 ? vSteer : turnKey;
    this.onFootTurnVel = THREE.MathUtils.damp(this.onFootTurnVel, turn * 2.65, 14, dt);
    this.onFootYaw -= this.onFootTurnVel * dt;

    const running =
      has('ShiftLeft') ||
      has('ShiftRight') ||
      Boolean(this.virtualInputs.clutch) ||
      Math.abs(this.virtualStickY) > 0.88 ||
      vThrottle > 0.85;
    const maxSpeed = moveFwd >= 0 ? (running ? 5.9 : 2.95) : (running ? 3.8 : 2.25);
    const targetSpeed = moveFwd * maxSpeed;
    if (Math.abs(targetSpeed) > 0.1) {
      this.onFootDirSign = targetSpeed >= 0 ? 1 : -1;
    }

    const fwdX = Math.cos(this.onFootYaw);
    const fwdZ = -Math.sin(this.onFootYaw);
    const targetVx = fwdX * targetSpeed;
    const targetVz = fwdZ * targetSpeed;

    this.onFootVel.x = THREE.MathUtils.damp(this.onFootVel.x, targetVx, 13, dt);
    this.onFootVel.z = THREE.MathUtils.damp(this.onFootVel.z, targetVz, 13, dt);
    this.onFootPos.x += this.onFootVel.x * dt;
    this.onFootPos.z += this.onFootVel.z * dt;

    this.resolveOnFootBikeCollision();

    // Clamp to open-world city bounds
    const maxBound = WORLD_HALF_EXTENT - 14;
    this.onFootPos.x = THREE.MathUtils.clamp(this.onFootPos.x, -maxBound, maxBound);
    this.onFootPos.z = THREE.MathUtils.clamp(this.onFootPos.z, -maxBound, maxBound);

    this.terrain.sampleGround(this.onFootPos.x, this.onFootPos.z, this.footHit);

    const vJump = Boolean(this.virtualInputs.rearBrake && this.virtualInputs.rearBrake > 0.5);
    const jumpPressed = has('Space') || (vJump && !this.prevVirtualJump);
    this.prevVirtualJump = vJump;

    if (jumpPressed && !this.onFootAirborne) {
      this.onFootVertVel = 4.9;
      this.onFootAirborne = true;
    }

    if (this.onFootAirborne) {
      this.onFootVertVel -= 14.5 * dt;
      this.onFootPos.y += this.onFootVertVel * dt;
      if (this.onFootPos.y <= this.footHit.height) {
        this.onFootPos.y = this.footHit.height;
        this.onFootVertVel = 0;
        this.onFootAirborne = false;
      }
    } else {
      this.onFootPos.y = THREE.MathUtils.damp(this.onFootPos.y, this.footHit.height, 28, dt);
    }

    const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
    if (!this.onFootAirborne && horizSpeed > 0.14) {
      this.walkPhase += horizSpeed * 2.25 * dt * this.onFootDirSign;
    }
  }

  private updateCamera(dt: number): void {
    this.camEffectTime += dt;

    // Right analog stick camera look across all camera modes
    const hasStickLook =
      Math.abs(this.virtualCamLookX) > 0.04 || Math.abs(this.virtualCamLookY) > 0.04;
    if (hasStickLook) {
      if (this.cameraMode === 'first_person') {
        if (this.riderState === 'on_foot' && !this.approachingMount) {
          this.onFootYaw -= this.virtualCamLookX * 2.45 * dt;
          this.fpLookPitch = THREE.MathUtils.clamp(
            this.fpLookPitch - this.virtualCamLookY * 1.95 * dt,
            -1.30,
            1.15
          );
        } else {
          this.fpLookYaw = THREE.MathUtils.clamp(
            this.fpLookYaw - this.virtualCamLookX * 2.25 * dt,
            -1.65,
            1.65
          );
          this.fpLookPitch = THREE.MathUtils.clamp(
            this.fpLookPitch - this.virtualCamLookY * 1.85 * dt,
            -0.55,
            0.55
          );
        }
      } else if (this.cameraMode === 'free_orbit') {
        this._v1.copy(this.camera.position).sub(this.orbitControls.target);
        const radius = Math.max(0.8, this._v1.length());
        let theta = Math.atan2(this._v1.x, this._v1.z);
        let phi = Math.acos(THREE.MathUtils.clamp(this._v1.y / radius, -0.99, 0.99));
        theta -= this.virtualCamLookX * 2.2 * dt;
        phi = THREE.MathUtils.clamp(phi + this.virtualCamLookY * 1.6 * dt, 0.14, Math.PI * 0.48);
        this._v1.set(
          radius * Math.sin(phi) * Math.sin(theta),
          radius * Math.cos(phi),
          radius * Math.sin(phi) * Math.cos(theta)
        );
        this.camera.position.copy(this.orbitControls.target).add(this._v1);
      } else {
        this.chaseLookYawOffset = THREE.MathUtils.clamp(
          this.chaseLookYawOffset - this.virtualCamLookX * 2.35 * dt,
          -2.8,
          2.8
        );
        this.chaseLookPitchOffset = THREE.MathUtils.clamp(
          this.chaseLookPitchOffset + this.virtualCamLookY * 1.4 * dt,
          -0.45,
          0.95
        );
      }
    } else if (this.cameraMode !== 'first_person' && this.cameraMode !== 'free_orbit') {
      const movingFast = Math.hypot(this.physics.vel.x, this.physics.vel.z) > 2.5;
      const dampRate = this.riderState === 'mounted' && movingFast ? 1.3 : 0.35;
      this.chaseLookYawOffset = THREE.MathUtils.damp(this.chaseLookYawOffset, 0, dampRate, dt);
      this.chaseLookPitchOffset = THREE.MathUtils.damp(this.chaseLookPitchOffset, 0, dampRate, dt);
    }

    if (this.cameraMode === 'free_orbit') {
      this.orbitControls.update();
      return;
    }

    if (this.riderState === 'on_foot' || this.approachingMount) {
      const isFp = this.cameraMode === 'first_person';
      const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);

      if (isFp) {
        this.camera.up.copy(this._up);
        this.fpLookYaw = THREE.MathUtils.damp(this.fpLookYaw, 0, 12, dt);
        const onFootFpFov = THREE.MathUtils.clamp(
          this.fpFov + 4 + Math.min(4.5, horizSpeed * 0.65),
          72,
          118
        );
        this.camera.fov = THREE.MathUtils.damp(this.camera.fov, onFootFpFov, 10, dt);
        this.camera.updateProjectionMatrix();

        this.rig.footCamAnchor.getWorldPosition(this._v1);
        this.camera.position.copy(this._v1);

        // Natural eye horizon with smooth full look-down to sneakers & look-up to rooftops
        const lookYaw = this.onFootYaw + this.fpLookYaw;
        const pitchLook = THREE.MathUtils.clamp(-0.08 + this.fpLookPitch, -1.30, 1.15);
        const cosP = Math.cos(pitchLook);
        const sinP = Math.sin(pitchLook);
        this._v2.set(
          this._v1.x + Math.cos(lookYaw) * cosP * 10,
          this._v1.y + sinP * 10,
          this._v1.z - Math.sin(lookYaw) * cosP * 10
        );
        this.camera.lookAt(this._v2);
        return;
      }

      this.camera.up.copy(this._up);
      const targetFov = this.cameraMode === 'moto_vlog' ? 68 : 64 + Math.min(6, horizSpeed * 0.7);
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 10, dt);
      this.camera.updateProjectionMatrix();

      this.camYaw = dampAngle(this.camYaw, this.onFootYaw + this.chaseLookYawOffset, 11, dt);
      const fwdX = Math.cos(this.camYaw);
      const fwdZ = -Math.sin(this.camYaw);
      const rightX = Math.sin(this.camYaw);
      const rightZ = Math.cos(this.camYaw);

      if (this.cameraMode === 'moto_vlog') {
        this._v1.set(
          this.onFootPos.x - fwdX * 2.25 + rightX * 1.05,
          this.onFootPos.y + 1.52 + this.chaseLookPitchOffset,
          this.onFootPos.z - fwdZ * 2.25 + rightZ * 1.05
        );
      } else {
        this._v1.set(
          this.onFootPos.x - fwdX * 2.75 + rightX * 0.28,
          this.onFootPos.y + 1.68 + this.chaseLookPitchOffset,
          this.onFootPos.z - fwdZ * 2.75 + rightZ * 0.28
        );
      }
      this._v2.set(
        this.onFootPos.x + fwdX * 1.4,
        this.onFootPos.y + 1.25,
        this.onFootPos.z + fwdZ * 1.4
      );
      this.camPos.lerp(this._v1, 1 - Math.exp(-16 * dt));
      this.camLook.lerp(this._v2, 1 - Math.exp(-20 * dt));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(this.camLook);
      return;
    }

    const speedMs = Math.hypot(this.physics.vel.x, this.physics.vel.z);
    const isRiding = this.riderState === 'mounted';
    const rawAccel = dt > 1e-4 ? THREE.MathUtils.clamp((speedMs - this.prevSpeedMs) / dt, -14, 16) : 0;
    this.prevSpeedMs = speedMs;

    this.smoothThrottleEffect = THREE.MathUtils.damp(
      this.smoothThrottleEffect,
      isRiding ? this.inputs.throttle : 0,
      7.5,
      dt
    );
    this.smoothAccelG = THREE.MathUtils.damp(this.smoothAccelG, isRiding ? rawAccel : 0, 7.0, dt);

    const speedNorm = THREE.MathUtils.clamp(speedMs / 42, 0, 1);
    const wheelieNorm = THREE.MathUtils.clamp(this.physics.wheeliePitch / 1.15, 0, 1);
    const isScraping = THREE.MathUtils.radToDeg(this.physics.wheeliePitch) >= 76 && speedMs > 3;
    const shakeAmp = isRiding
      ? speedNorm * 0.0040 +
        this.smoothThrottleEffect * (0.0018 + speedNorm * 0.0022) +
        (isScraping ? 0.0060 : 0)
      : 0;
    const shakeX =
      shakeAmp * (Math.sin(this.camEffectTime * 37) * 0.6 + Math.cos(this.camEffectTime * 53) * 0.4);
    const shakeY =
      shakeAmp * (Math.cos(this.camEffectTime * 43) * 0.65 + Math.sin(this.camEffectTime * 61) * 0.35);

    if (this.cameraMode === 'first_person') {
      const standBlend = this.riderState === 'mounted' ? 0 : this.transitionT;
      const mountedFov =
        this.fpFov +
        speedNorm * 7.5 +
        this.smoothThrottleEffect * 4.2 +
        Math.max(0, this.smoothAccelG) * 0.25;
      const standingFov = THREE.MathUtils.clamp(this.fpFov + 4, 72, 118);
      const targetFov = THREE.MathUtils.lerp(mountedFov, standingFov, standBlend);
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 9, dt);
      this.camera.updateProjectionMatrix();

      // Acceleration Cockpit Tuck (moves slightly closer to dash/bars on throttle) + suspension inertia
      const targetPitchLag = isRiding
        ? -this.smoothThrottleEffect * 0.018 * (1 - wheelieNorm) +
          this.smoothThrottleEffect * 0.014 * wheelieNorm -
          this.inputs.frontBrake * 0.036 -
          this.physics.frontSuspVel * 0.045
        : 0;
      const targetFwdShift = isRiding
        ? this.smoothThrottleEffect * (0.088 - wheelieNorm * 0.042) -
          this.inputs.frontBrake * 0.034 -
          Math.max(0, this.smoothAccelG) * 0.0018
        : 0;
      const targetDropLag = isRiding
        ? -(this.physics.frontSusp - 0.032) * 0.38 -
          this.smoothThrottleEffect * 0.022 * (1 - wheelieNorm) -
          THREE.MathUtils.clamp(this.physics.verticalVel * 0.008, -0.04, 0.04)
        : 0;

      this.fpHeadPitchLag = THREE.MathUtils.damp(this.fpHeadPitchLag, targetPitchLag, 10, dt);
      this.fpHeadBackLag = THREE.MathUtils.damp(this.fpHeadBackLag, targetFwdShift, 8.5, dt);
      this.fpHeadDropLag = THREE.MathUtils.damp(this.fpHeadDropLag, targetDropLag, 12, dt);

      const fwdBikeX = Math.cos(this.physics.yaw);
      const fwdBikeZ = -Math.sin(this.physics.yaw);
      const rightBikeX = Math.sin(this.physics.yaw);
      const rightBikeZ = Math.cos(this.physics.yaw);

      // Move helmet closer to cockpit on throttle + subtle wind/engine micro-shake
      this.rig.headCamAnchor.getWorldPosition(this._v1);
      this._v1.x += fwdBikeX * this.fpHeadBackLag + rightBikeX * shakeX;
      this._v1.z += fwdBikeZ * this.fpHeadBackLag + rightBikeZ * shakeX;
      this._v1.y += this.fpHeadDropLag + shakeY;
      this.camera.position.copy(this._v1);

      // Balanced, reduced first-person turn follow when riding; aligns seamlessly to physics.yaw at standBlend=1
      this.fpCamYaw = dampAngle(this.fpCamYaw, this.physics.yaw, 3.4 + standBlend * 14, dt);
      const yawLag = Math.atan2(
        Math.sin(this.physics.yaw - this.fpCamYaw),
        Math.cos(this.physics.yaw - this.fpCamYaw)
      );
      if (Math.abs(yawLag) > 0.42 && standBlend < 0.1) {
        this.fpCamYaw = this.physics.yaw - Math.sign(yawLag) * 0.42;
      }

      const lookYaw = this.fpCamYaw + this.fpLookYaw * (1 - standBlend * 0.4);
      const fwdX = Math.cos(lookYaw);
      const fwdZ = -Math.sin(lookYaw);
      const pitchLook = THREE.MathUtils.clamp(
        (-0.39 + this.physics.wheeliePitch * 0.62) * (1 - standBlend) +
          -0.08 * standBlend +
          this.fpHeadPitchLag +
          this.fpLookPitch,
        -1.30,
        1.15
      );
      const cosP = Math.cos(pitchLook);
      const sinP = Math.sin(pitchLook);

      this._v2.set(
        this._v1.x + fwdX * cosP * 10,
        this._v1.y + sinP * 10,
        this._v1.z + fwdZ * cosP * 10
      );

      // Gentle horizon-stabilized helmet roll + subtle high-speed wind shimmer
      const windRoll =
        isRiding
          ? Math.sin(this.camEffectTime * 19) *
            (speedNorm * 0.004 + this.smoothThrottleEffect * 0.0025)
          : 0;
      const headRoll = (this.physics.leanAngle * 0.08 + windRoll) * (1 - standBlend);
      this._v3.set(
        Math.sin(lookYaw) * Math.sin(headRoll),
        Math.cos(headRoll),
        Math.cos(lookYaw) * Math.sin(headRoll)
      );
      this.camera.up.copy(this._v3).normalize();
      this.camera.lookAt(this._v2);
      return;
    }

    // Crisp Polar Chase Camera with acceleration FOV surge & punchy elastic launch feel
    this.camera.up.copy(this._up);
    const fovOffset = this.fpFov - 78;
    const targetFov = THREE.MathUtils.clamp(
      (this.cameraMode === 'moto_vlog' ? 68 : 62 + speedNorm * 10.5) +
        this.smoothThrottleEffect * 4.2 +
        Math.max(0, this.smoothAccelG) * 0.22 +
        fovOffset * 0.65,
      48,
      110
    );
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 10, dt);
    this.camera.updateProjectionMatrix();

    this.camYaw = dampAngle(
      this.camYaw,
      this.physics.yaw - this.inputs.steer * 0.06 + this.chaseLookYawOffset,
      13.5,
      dt
    );
    const camFwdX = Math.cos(this.camYaw);
    const camFwdZ = -Math.sin(this.camYaw);
    const camRightX = Math.sin(this.camYaw);
    const camRightZ = Math.cos(this.camYaw);

    const bikeFwdX = Math.cos(this.physics.yaw);
    const bikeFwdZ = -Math.sin(this.physics.yaw);

    const launchStretch = Math.max(0, this.smoothAccelG) * 0.018 - this.smoothThrottleEffect * 0.14;

    if (this.cameraMode === 'moto_vlog') {
      const vlogDist = 2.55 + launchStretch * 0.7;
      this._v1.set(
        this.physics.pos.x - camFwdX * vlogDist + camRightX * 1.35 + camRightX * shakeX * 1.4,
        this.physics.pos.y + 1.42 + Math.sin(this.physics.wheeliePitch) * 0.35 + this.chaseLookPitchOffset + shakeY * 1.4,
        this.physics.pos.z - camFwdZ * vlogDist + camRightZ * 1.35 + camRightZ * shakeX * 1.4
      );
      this._v2.set(
        this.physics.pos.x + bikeFwdX * 1.4,
        this.physics.pos.y + 0.92 + Math.sin(this.physics.wheeliePitch) * 0.35,
        this.physics.pos.z + bikeFwdZ * 1.4
      );
    } else {
      const chaseDist = 3.55 + launchStretch;
      this._v1.set(
        this.physics.pos.x - camFwdX * chaseDist + camRightX * shakeX * 1.5,
        this.physics.pos.y + 1.62 + Math.sin(this.physics.wheeliePitch) * 0.24 + this.chaseLookPitchOffset + shakeY * 1.5,
        this.physics.pos.z - camFwdZ * chaseDist + camRightZ * shakeX * 1.5
      );
      this._v2.set(
        this.physics.pos.x + bikeFwdX * 2.65,
        this.physics.pos.y + 0.96 + Math.sin(this.physics.wheeliePitch) * 0.34,
        this.physics.pos.z + bikeFwdZ * 2.65
      );
    }

    this.camPos.lerp(this._v1, 1 - Math.exp(-22 * dt));
    this.camLook.lerp(this._v2, 1 - Math.exp(-24 * dt));
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);
  }

  private emitParticles(): void {
    if (this.riderState !== 'mounted') return;
    const fwdX = Math.cos(this.physics.yaw);
    const fwdZ = -Math.sin(this.physics.yaw);

    // Rear tire smoke during burnout or heavy rear slip
    if (this.physics.rearSlip > 0.35 || this.inputs.burnout) {
      const smokeProb = this.graphicsQuality === 'low' ? 0.35 : 0.8;
      if (Math.random() < smokeProb) {
        this.world.spawnSmoke(
          this.physics.pos.x - fwdX * 0.78,
          this.physics.pos.y,
          this.physics.pos.z - fwdZ * 0.78,
          -fwdX * 1.8,
          0.4,
          -fwdZ * 1.8
        );
      }
    }

    // Metallic sparks during Raspão (tail scrape > 76 deg)
    const degW = THREE.MathUtils.radToDeg(this.physics.wheeliePitch);
    if (degW >= 76 && Math.hypot(this.physics.vel.x, this.physics.vel.z) > 3) {
      const sparkCount = this.graphicsQuality === 'low' ? 2 : this.graphicsQuality === 'ultra' ? 7 : 5;
      this.world.spawnSparks(
        this.physics.pos.x - fwdX * 1.15,
        this.physics.pos.y + 0.08,
        this.physics.pos.z - fwdZ * 1.15,
        -this.physics.vel.x,
        -this.physics.vel.z,
        sparkCount
      );
    }
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const dt = Math.min((now - this.lastTime) / 1000, 0.05);
    this.lastTime = now;

    if (this.dismountHintTimer > 0) {
      this.dismountHintTimer = Math.max(0, this.dismountHintTimer - dt);
      if (this.dismountHintTimer === 0) this.dismountHint = '';
    }
    if (!this.emoteHoldActive && this.timedEmoteTimer > 0) {
      this.timedEmoteTimer = Math.max(0, this.timedEmoteTimer - dt);
      if (this.timedEmoteTimer === 0) {
        this.timedEmote = 'none';
        this.emoteDragX = 0;
        this.emoteDragY = 0;
      }
    }

    this.smoothEmoteDragX = THREE.MathUtils.damp(this.smoothEmoteDragX, this.emoteDragX, 18, dt);
    this.smoothEmoteDragY = THREE.MathUtils.damp(this.smoothEmoteDragY, this.emoteDragY, 18, dt);

    const isFp = this.cameraMode === 'first_person';
    this.gatherInputs(dt);
    const activeEmote: EmoteId = this.inputs.emote ?? 'none';

    if (this.riderState === 'mounted') {
      this.physics.step(dt, this.inputs);
      this.rig.update(this.physics, isFp, dt, this.inputs);
    } else if (this.riderState === 'dismounting') {
      this.physics.stepParked(dt, false);
      this.transitionT = Math.min(1, this.transitionT + dt / 0.78);
      this.rig.updateTransition(this.physics, this.transitionT, isFp, dt);
      if (this.transitionT >= 1) {
        this.riderState = 'on_foot';
        this.rig.getLeftStandWorldPos(this.onFootPos);
        this.terrain.sampleGround(this.onFootPos.x, this.onFootPos.z, this.footHit);
        this.onFootPos.y = this.footHit.height;
        this.onFootVel.set(0, 0, 0);
        this.onFootVertVel = 0;
        this.onFootTurnVel = 0;
        this.onFootDirSign = 1;
        this.onFootAirborne = false;
        this.onFootYaw = this.physics.yaw;
        this.walkPhase = 0;
        this.rig.updateOnFoot(
          this.physics,
          this.onFootPos,
          this.onFootYaw,
          0,
          false,
          0,
          'none',
          isFp,
          dt,
          0,
          0,
          1
        );
      }
    } else if (this.riderState === 'on_foot') {
      this.physics.stepParked(dt, false);
      this.stepOnFoot(dt);
      const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
      this.rig.updateOnFoot(
        this.physics,
        this.onFootPos,
        this.onFootYaw,
        horizSpeed,
        this.onFootAirborne,
        this.walkPhase,
        activeEmote,
        isFp,
        dt,
        this.onFootTurnVel,
        this.onFootVertVel,
        this.onFootDirSign
      );
    } else if (this.riderState === 'mounting') {
      this.physics.stepParked(dt, true);
      if (this.approachingMount) {
        this.stepMountApproach(dt);
        const horizSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);
        this.rig.updateOnFoot(
          this.physics,
          this.onFootPos,
          this.onFootYaw,
          horizSpeed,
          false,
          this.walkPhase,
          'none',
          isFp,
          dt,
          this.onFootTurnVel,
          0,
          1
        );
      } else {
        this.transitionT = Math.max(0, this.transitionT - dt / 0.74);
        this.rig.updateTransition(this.physics, this.transitionT, isFp, dt);
        if (this.transitionT <= 0) {
          this.riderState = 'mounted';
          this.fpLookYaw = 0;
          this.fpLookPitch = 0;
          this.rig.update(this.physics, isFp, dt, this.inputs);
        }
      }
    }

    this.updateCamera(dt);
    if (this.rig.hasEmoteActive()) {
      this.rig.applyInteractiveEmote(
        this.camera,
        isFp,
        this.riderState === 'on_foot',
        this.smoothEmoteDragX,
        this.smoothEmoteDragY,
        this.physics
      );
    }

    // 3D iPhone pull-out animation, Maps telemetry & hand grip pose
    const mountedSpeedKmh = Math.hypot(this.physics.vel.x, this.physics.vel.z) * 3.6;
    if (this.isPhoneOpen && this.riderState === 'mounted' && mountedSpeedKmh > 32) {
      this.isPhoneOpen = false;
      this.draggingPhoneScreen = false;
      this.setHint('iPhone guardado em alta velocidade');
    }
    const phoneAllowed = this.riderState === 'on_foot' || this.riderState === 'mounted';
    const phoneTarget = this.isPhoneOpen && phoneAllowed && !this.physics.crashed ? 1 : 0;
    this.phoneBlend = THREE.MathUtils.damp(this.phoneBlend, phoneTarget, 11.5, dt);

    const isOnFoot = this.riderState === 'on_foot';
    const playerX = isOnFoot ? this.onFootPos.x : this.physics.pos.x;
    const playerZ = isOnFoot ? this.onFootPos.z : this.physics.pos.z;
    const playerYawRad = isOnFoot ? this.onFootYaw : this.physics.yaw;
    const onFootSpeed = Math.hypot(this.onFootVel.x, this.onFootVel.z);

    this.iphone.setTelemetry({
      playerX,
      playerZ,
      playerYawRad,
      bikeX: this.physics.pos.x,
      bikeZ: this.physics.pos.z,
      bikeYawRad: this.physics.yaw,
      speedKmh: Math.round(isOnFoot ? onFootSpeed * 3.6 : mountedSpeedKmh),
      riderState: this.riderState,
    });
    this.iphone.update(dt, this.phoneBlend > 0.015);
    this.rig.applyPhoneHoldPose(
      this.iphone.root,
      this.camera,
      isFp,
      isOnFoot,
      this.phoneBlend,
      this.iphone.consumeTapFeedback(),
      isOnFoot ? onFootSpeed : 0,
      this.walkPhase
    );
    this.rig.updateHelmet(
      dt,
      this.camera,
      isFp,
      isOnFoot,
      this.transitionT,
      this.rig.hasEmoteActive(),
      this.phoneBlend
    );

    this.emitParticles();
    const activeFocusPos = this.riderState === 'on_foot' ? this.onFootPos : this.physics.pos;
    this.world.updateParticles(dt, this.camera.position, activeFocusPos);

    this.renderIPhoneCameraPass(now, isFp, isOnFoot);

    this.camera.updateMatrixWorld(true);
    this.world.renderGroundReflection(
      this.renderer,
      this.scene,
      this.camera,
      activeFocusPos,
      dt,
      () => {
        this.rig.contactShadowMesh.visible = false;
      },
      () => {
        this.rig.contactShadowMesh.visible = true;
      }
    );

    this.renderer.render(this.scene, this.camera);

    this.hudTimer += dt;
    if (this.hudTimer >= 0.045) {
      this.hudTimer = 0;
      const telemetry = this.physics.getTelemetry();
      telemetry.clutchEngaged = !this.inputs.clutch;
      telemetry.riderState = this.riderState;
      telemetry.dismountHint = this.dismountHint;
      telemetry.activeEmote = activeEmote;
      telemetry.isPhoneOpen = this.isPhoneOpen;
      telemetry.phoneApp = this.iphone.activeApp;
      telemetry.helmetOn = this.rig.isHelmetOn();
      telemetry.helmetAnimating = this.rig.isHelmetAnimating();
      if (this.riderState === 'on_foot') {
        telemetry.speedKmh = Math.round(onFootSpeed * 3.6);
        telemetry.posX = this.onFootPos.x;
        telemetry.posZ = this.onFootPos.z;
        telemetry.yawRad = this.onFootYaw;
        telemetry.nearBike =
          Math.hypot(this.onFootPos.x - this.physics.pos.x, this.onFootPos.z - this.physics.pos.z) <= 4.2;
      } else {
        telemetry.nearBike = true;
      }
      this.audio.update(telemetry, this.riderState === 'mounted' ? this.inputs.throttle : 0);
      this.onTelemetry(telemetry);
    }

    this.scheduleNextFrame();
  };

  private renderIPhoneCameraPass(nowMs: number, isFirstPerson: boolean, isOnFoot: boolean): void {
    if (!this.iphone.shouldRenderLiveCamera(nowMs)) return;

    const targetFov = this.iphone.getCameraFovDeg();
    const targetFar = this.iphone.getLiveCameraFar();
    if (this.phoneLiveCamera.fov !== targetFov || this.phoneLiveCamera.far !== targetFar) {
      this.phoneLiveCamera.fov = targetFov;
      this.phoneLiveCamera.far = targetFar;
      this.phoneLiveCamera.updateProjectionMatrix();
    }

    this.iphone.root.updateMatrixWorld(true);
    this._phCamPos.setFromMatrixPosition(this.iphone.root.matrixWorld);
    this._phCamRight.setFromMatrixColumn(this.iphone.root.matrixWorld, 0).normalize();
    this._phCamUp.setFromMatrixColumn(this.iphone.root.matrixWorld, 1).normalize();
    this._phCamFwd.setFromMatrixColumn(this.iphone.root.matrixWorld, 2).normalize(); // +Z screen front

    const isSelfie = this.iphone.cameraSelfie;
    if (isSelfie) {
      this.phoneLiveCamera.position
        .copy(this._phCamPos)
        .addScaledVector(this._phCamUp, 0.068)
        .addScaledVector(this._phCamFwd, 0.014);
      this._phCamLook.copy(this.phoneLiveCamera.position).addScaledVector(this._phCamFwd, 1.0);
    } else {
      this.phoneLiveCamera.position
        .copy(this._phCamPos)
        .addScaledVector(this._phCamRight, -0.015)
        .addScaledVector(this._phCamUp, 0.052)
        .addScaledVector(this._phCamFwd, -0.016);
      this._phCamLook.copy(this.phoneLiveCamera.position).addScaledVector(this._phCamFwd, -1.0);
    }
    this.phoneLiveCamera.up.copy(this._phCamUp);
    this.phoneLiveCamera.lookAt(this._phCamLook);
    this.phoneLiveCamera.updateMatrixWorld(true);

    const prevTarget = this.renderer.getRenderTarget();
    const prevPhoneVisible = this.iphone.root.visible;
    const prevRealReflectVal = this.world.reflector.uniforms.uRealGroundReflection.value;
    const revealHeadForSelfie = isSelfie && isFirstPerson;

    this.iphone.root.visible = false;
    this.world.reflector.uniforms.uRealGroundReflection.value = 0;
    if (revealHeadForSelfie) {
      this.rig.setFirstPersonMode(false, isOnFoot);
      this.rig.root.updateMatrixWorld(true);
    }

    this.renderer.setRenderTarget(this.iphone.cameraRenderTarget);
    this.renderer.clear();
    this.renderer.render(this.scene, this.phoneLiveCamera);
    this.iphone.capturePendingSnapshot(this.renderer);
    this.renderer.setRenderTarget(prevTarget);

    if (revealHeadForSelfie) {
      this.rig.setFirstPersonMode(true, isOnFoot);
      this.rig.root.updateMatrixWorld(true);
    }
    this.world.reflector.uniforms.uRealGroundReflection.value = prevRealReflectVal;
    this.iphone.root.visible = prevPhoneVisible;
    this.iphone.markCameraRendered(nowMs);
  }

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResize);
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    this.renderer.domElement.removeEventListener('pointerdown', this.handlePointerDown);
    this.renderer.domElement.removeEventListener('pointermove', this.handlePointerMove);
    window.removeEventListener('pointerup', this.handlePointerUp);
    window.removeEventListener('pointercancel', this.handlePointerUp);
    this.renderer.domElement.removeEventListener('wheel', this.handleWheel);
    this.renderer.domElement.removeEventListener('mousemove', this.handleMouseMove);
    this.renderer.domElement.removeEventListener('mousedown', this.handleMouseDown);
    window.removeEventListener('mouseup', this.handleMouseUp);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);

    this.orbitControls.dispose();
    this.audio.dispose();
    this.iphone.dispose();
    this.world.dispose();
    this.textures.dispose();
    this.studioEnv.dispose();
    this.outdoorSkyEnv.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
