import { TelemetryState } from './types';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private oscPrimary: OscillatorNode | null = null;
  private oscSub: OscillatorNode | null = null;
  private oscHarm: OscillatorNode | null = null;
  private exhaustFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private scrapeGain: GainNode | null = null;
  private muted = false;
  private started = false;

  public start(): void {
    if (this.started) {
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    try {
      const ctx = new AudioCtx();
      this.ctx = ctx;

      const master = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.28;
      master.connect(ctx.destination);
      this.masterGain = master;

      // Exhaust resonant filter
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 320;
      filter.Q.value = 3.2;

      const engGain = ctx.createGain();
      engGain.gain.value = 0.25;
      filter.connect(engGain);
      engGain.connect(master);

      this.exhaustFilter = filter;
      this.engineGain = engGain;

      // V4 multi-harmonic firing oscillators
      const osc1 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.value = 48;
      osc1.connect(filter);
      osc1.start();

      const osc2 = ctx.createOscillator();
      osc2.type = 'triangle';
      osc2.frequency.value = 24;
      osc2.connect(filter);
      osc2.start();

      const osc3 = ctx.createOscillator();
      osc3.type = 'sawtooth';
      osc3.frequency.value = 72;
      osc3.detune.value = 14;
      const g3 = ctx.createGain();
      g3.gain.value = 0.35;
      osc3.connect(g3);
      g3.connect(filter);
      osc3.start();

      this.oscPrimary = osc1;
      this.oscSub = osc2;
      this.oscHarm = osc3;

      // Procedural filtered white noise for wind & scrape sparks
      const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const windSrc = ctx.createBufferSource();
      windSrc.buffer = noiseBuf;
      windSrc.loop = true;
      const windFilt = ctx.createBiquadFilter();
      windFilt.type = 'bandpass';
      windFilt.frequency.value = 460;
      windFilt.Q.value = 0.7;
      const wGain = ctx.createGain();
      wGain.gain.value = 0;
      windSrc.connect(windFilt);
      windFilt.connect(wGain);
      wGain.connect(master);
      windSrc.start();
      this.windGain = wGain;

      const scrapeSrc = ctx.createBufferSource();
      scrapeSrc.buffer = noiseBuf;
      scrapeSrc.loop = true;
      const scrapeFilt = ctx.createBiquadFilter();
      scrapeFilt.type = 'highpass';
      scrapeFilt.frequency.value = 2400;
      const sGain = ctx.createGain();
      sGain.gain.value = 0;
      scrapeSrc.connect(scrapeFilt);
      scrapeFilt.connect(sGain);
      sGain.connect(master);
      scrapeSrc.start();
      this.scrapeGain = sGain;

      this.started = true;
    } catch {
      // Audio blocked or unsupported
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.28, this.ctx.currentTime, 0.04);
    }
  }

  public update(telemetry: TelemetryState, throttle: number): void {
    if (!this.started || !this.ctx || !this.oscPrimary || !this.oscSub || !this.oscHarm) return;
    const now = this.ctx.currentTime;

    // Firing frequency: Honda CG 160 Titan single-cylinder thump
    const baseHz = Math.max(20, (telemetry.rpm / 60) * 0.96);
    this.oscPrimary.frequency.setTargetAtTime(baseHz, now, 0.025);
    this.oscSub.frequency.setTargetAtTime(baseHz * 0.5, now, 0.025);
    this.oscHarm.frequency.setTargetAtTime(baseHz * 2.0, now, 0.025);

    if (this.exhaustFilter && this.engineGain) {
      const cutoff = 260 + (telemetry.rpm / telemetry.maxRpm) * 1450 + throttle * 520;
      this.exhaustFilter.frequency.setTargetAtTime(cutoff, now, 0.03);
      const limiterChop = telemetry.revLimiter && Math.sin(now * 68) > 0 ? 0.14 : 1.0;
      const vol = (0.16 + throttle * 0.22 + (telemetry.rpm / telemetry.maxRpm) * 0.15) * limiterChop;
      this.engineGain.gain.setTargetAtTime(telemetry.crashed ? 0.02 : vol, now, 0.02);
    }

    if (this.windGain) {
      const windVol = Math.min(0.28, Math.pow(telemetry.speedKmh / 180, 1.6) * 0.26);
      this.windGain.gain.setTargetAtTime(windVol, now, 0.06);
    }

    if (this.scrapeGain) {
      const scrapeVol = telemetry.isScrape && telemetry.speedKmh > 10 ? 0.24 : 0;
      this.scrapeGain.gain.setTargetAtTime(scrapeVol, now, 0.03);
    }
  }

  public dispose(): void {
    try {
      this.oscPrimary?.stop();
      this.oscSub?.stop();
      this.oscHarm?.stop();
      void this.ctx?.close();
    } catch {
      // ignore
    }
  }
}
