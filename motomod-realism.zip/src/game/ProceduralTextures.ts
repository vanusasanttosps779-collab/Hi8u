import * as THREE from 'three';
import asphaltAiUrl from '../assets/images/asphalt_road_4k_1794935673909.jpg';
import brickAiUrl from '../assets/images/tijolo_baiano_tex_1794936082390.jpg';
import concreteAiUrl from '../assets/images/concrete_sidewalk_tex_1794936083384.jpg';
import roofAiUrl from '../assets/images/telha_zinco_tex_1794936083800.jpg';
import gloveAiUrl from '../assets/images/glove_leather_tex_1794936727345.jpg';
import skyAiUrl from '../assets/images/realistic_sky_dome_1794939158602.jpg';

export interface ProceduralTextureSet {
  asphaltMap: THREE.CanvasTexture;
  asphaltRoughness: THREE.CanvasTexture;
  brickMap: THREE.CanvasTexture;
  concreteMap: THREE.CanvasTexture;
  roofMap: THREE.CanvasTexture;
  gloveMap: THREE.CanvasTexture;
  skyMap: THREE.CanvasTexture;
  carbonMap: THREE.CanvasTexture;
  particleGlow: THREE.CanvasTexture;
  contactShadow: THREE.CanvasTexture;
  signLombadaMap: THREE.CanvasTexture;
  dispose: () => void;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function makeAiRepeatTexture(
  url: string,
  res: number,
  fallbackHex: string,
  maxAnisotropy: number,
  grainAlpha = 0.08
): THREE.CanvasTexture {
  const [canvas, ctx] = makeCanvas(res, res);
  ctx.fillStyle = fallbackHex;
  ctx.fillRect(0, 0, res, res);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;

  const img = new Image();
  img.onload = () => {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, res, res);

    if (grainAlpha > 0) {
      const [gCanvas, gCtx] = makeCanvas(128, 128);
      const gData = gCtx.createImageData(128, 128);
      const d = gData.data;
      let seed = 48271;
      for (let i = 0; i < d.length; i += 4) {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        const v = 114 + ((seed >>> 24) & 27);
        d[i] = v;
        d[i + 1] = v;
        d[i + 2] = v;
        d[i + 3] = 255;
      }
      gCtx.putImageData(gData, 0, 0);
      const pat = ctx.createPattern(gCanvas, 'repeat');
      if (pat) {
        ctx.save();
        ctx.globalCompositeOperation = 'overlay';
        ctx.globalAlpha = grainAlpha;
        ctx.fillStyle = pat;
        ctx.fillRect(0, 0, res, res);
        ctx.restore();
      }
    }
    tex.needsUpdate = true;
  };
  img.src = url;

  return tex;
}

export function createProceduralTextures(
  maxAnisotropy: number,
  maxTextureSize = 4096
): ProceduralTextureSet {
  // 1. High-Res 4K AI-Generated Brazilian Urban Asphalt (capped safely to GPU maxTextureSize)
  const asphaltRes = Math.min(4096, Math.max(2048, maxTextureSize >= 4096 ? 4096 : maxTextureSize || 2048));
  const roughRes = Math.min(2048, asphaltRes);
  const envTexRes = Math.min(2048, maxTextureSize || 2048);

  const [asphCanvas, asphCtx] = makeCanvas(asphaltRes, asphaltRes);
  asphCtx.fillStyle = '#2b2d32';
  asphCtx.fillRect(0, 0, asphaltRes, asphaltRes);
  // Instant crisp base markings while bundled AI 4K image decodes
  const edgeW = Math.round(asphaltRes * 0.02);
  const edgeOff = Math.round(asphaltRes * 0.04);
  asphCtx.fillStyle = 'rgba(232, 232, 224, 0.75)';
  asphCtx.fillRect(edgeOff, 0, edgeW, asphaltRes);
  asphCtx.fillRect(asphaltRes - edgeOff - edgeW, 0, edgeW, asphaltRes);
  asphCtx.fillStyle = 'rgba(235, 178, 32, 0.88)';
  asphCtx.fillRect(Math.round(asphaltRes * 0.49), Math.round(asphaltRes * 0.05), edgeW, Math.round(asphaltRes * 0.36));
  asphCtx.fillRect(Math.round(asphaltRes * 0.49), Math.round(asphaltRes * 0.55), edgeW, Math.round(asphaltRes * 0.36));

  const asphaltMap = new THREE.CanvasTexture(asphCanvas);
  asphaltMap.colorSpace = THREE.SRGBColorSpace;
  asphaltMap.wrapS = THREE.ClampToEdgeWrapping;
  asphaltMap.wrapT = THREE.RepeatWrapping;
  asphaltMap.anisotropy = maxAnisotropy;

  // Asphalt roughness / micro-bump map
  const [roughCanvas, roughCtx] = makeCanvas(roughRes, roughRes);
  roughCtx.fillStyle = '#d4d4d4';
  roughCtx.fillRect(0, 0, roughRes, roughRes);
  const asphaltRoughness = new THREE.CanvasTexture(roughCanvas);
  asphaltRoughness.wrapS = THREE.ClampToEdgeWrapping;
  asphaltRoughness.wrapT = THREE.RepeatWrapping;
  asphaltRoughness.anisotropy = maxAnisotropy;

  // Composite bundled AI asphalt image onto 4K canvas + crisp basalt stone micro-grain pass
  const aiImg = new Image();
  aiImg.onload = () => {
    asphCtx.imageSmoothingEnabled = true;
    asphCtx.imageSmoothingQuality = 'high';
    asphCtx.drawImage(aiImg, 0, 0, asphaltRes, asphaltRes);

    // Tileable 256x256 basalt grit micro-detail overlay so 4K surface stays razor-sharp up close
    const [grainCanvas, grainCtx] = makeCanvas(256, 256);
    const grainData = grainCtx.createImageData(256, 256);
    const d = grainData.data;
    let seed = 918273;
    for (let i = 0; i < d.length; i += 4) {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      const g = 108 + ((seed >>> 24) & 31) + (((seed >>> 16) & 15) - 7);
      d[i] = g;
      d[i + 1] = g;
      d[i + 2] = g + 2;
      d[i + 3] = 255;
    }
    grainCtx.putImageData(grainData, 0, 0);
    const grainPattern = asphCtx.createPattern(grainCanvas, 'repeat');
    if (grainPattern) {
      asphCtx.save();
      asphCtx.globalCompositeOperation = 'overlay';
      asphCtx.globalAlpha = 0.16;
      asphCtx.fillStyle = grainPattern;
      asphCtx.fillRect(0, 0, asphaltRes, asphaltRes);
      asphCtx.restore();
    }

    // Derive roughness/bump contrast directly from the AI road image
    roughCtx.imageSmoothingEnabled = true;
    roughCtx.imageSmoothingQuality = 'high';
    roughCtx.drawImage(aiImg, 0, 0, roughRes, roughRes);
    const rImg = roughCtx.getImageData(0, 0, roughRes, roughRes);
    const rd = rImg.data;
    for (let i = 0; i < rd.length; i += 4) {
      const lum = rd[i] * 0.299 + rd[i + 1] * 0.587 + rd[i + 2] * 0.114;
      // Tire wear tracks (darker) slightly smoother for realistic golden-hour sun sheen; aggregate coarser
      const roughVal = Math.max(150, Math.min(248, Math.round(162 + (lum / 255) * 86)));
      rd[i] = roughVal;
      rd[i + 1] = roughVal;
      rd[i + 2] = roughVal;
      rd[i + 3] = 255;
    }
    roughCtx.putImageData(rImg, 0, 0);

    asphaltMap.needsUpdate = true;
    asphaltRoughness.needsUpdate = true;
  };
  aiImg.src = asphaltAiUrl;

  // 2. AI-Generated Realistic 2K Favela Tijolo Baiano, Concrete Sidewalk, Corrugated Roof & Racing Glove Leather
  const brickMap = makeAiRepeatTexture(brickAiUrl, envTexRes, '#b66b46', maxAnisotropy, 0.08);
  const concreteMap = makeAiRepeatTexture(concreteAiUrl, envTexRes, '#9b968e', maxAnisotropy, 0.10);
  const roofMap = makeAiRepeatTexture(roofAiUrl, envTexRes, '#6f6c67', maxAnisotropy, 0.07);
  const gloveMap = makeAiRepeatTexture(
    gloveAiUrl,
    Math.min(1024, maxTextureSize || 1024),
    '#c4c8ce',
    maxAnisotropy,
    0.04
  );
  gloveMap.repeat.set(1.6, 1.6);

  // AI-Generated Realistic Sky Panorama (Mirrored horizontal wrap for seamless 360° sky dome)
  const skyW = Math.min(2048, maxTextureSize || 2048);
  const skyH = Math.round(skyW * 0.5625);
  const [skyCanvas, skyCtx] = makeCanvas(skyW, skyH);
  const skyGrad = skyCtx.createLinearGradient(0, 0, 0, skyH);
  skyGrad.addColorStop(0.0, '#1f538d');
  skyGrad.addColorStop(0.48, '#6a9ed0');
  skyGrad.addColorStop(0.82, '#e2be9c');
  skyGrad.addColorStop(1.0, '#d9b89c');
  skyCtx.fillStyle = skyGrad;
  skyCtx.fillRect(0, 0, skyW, skyH);
  const skyMap = new THREE.CanvasTexture(skyCanvas);
  skyMap.colorSpace = THREE.SRGBColorSpace;
  skyMap.wrapS = THREE.MirroredRepeatWrapping;
  skyMap.wrapT = THREE.ClampToEdgeWrapping;
  skyMap.anisotropy = maxAnisotropy;
  const skyImg = new Image();
  skyImg.onload = () => {
    skyCtx.imageSmoothingEnabled = true;
    skyCtx.imageSmoothingQuality = 'high';
    skyCtx.drawImage(skyImg, 0, 0, skyW, skyH);
    skyMap.needsUpdate = true;
  };
  skyImg.src = skyAiUrl;

  // 3. Woven 2x2 Twill Carbon Fiber Texture (Ducati trim & glove knuckle armor)
  const [carbCanvas, carbCtx] = makeCanvas(128, 128);
  carbCtx.fillStyle = '#15171b';
  carbCtx.fillRect(0, 0, 128, 128);
  const cell = 8;
  for (let y = 0; y < 128; y += cell) {
    for (let x = 0; x < 128; x += cell) {
      const phase = ((x / cell + y / cell) % 4 + 4) % 4;
      const g = carbCtx.createLinearGradient(x, y, x + cell, y + cell);
      if (phase < 2) {
        g.addColorStop(0, '#2a2e36');
        g.addColorStop(0.5, '#3b404a');
        g.addColorStop(1, '#181a1f');
      } else {
        g.addColorStop(0, '#181a1f');
        g.addColorStop(0.5, '#252930');
        g.addColorStop(1, '#111317');
      }
      carbCtx.fillStyle = g;
      carbCtx.fillRect(x, y, cell, cell);
    }
  }
  const carbonMap = new THREE.CanvasTexture(carbCanvas);
  carbonMap.colorSpace = THREE.SRGBColorSpace;
  carbonMap.wrapS = THREE.RepeatWrapping;
  carbonMap.wrapT = THREE.RepeatWrapping;
  carbonMap.repeat.set(4, 4);
  carbonMap.anisotropy = maxAnisotropy;

  // 4. Radial Smoke / Spark Sprite
  const [partCanvas, partCtx] = makeCanvas(128, 128);
  const pg = partCtx.createRadialGradient(64, 64, 4, 64, 64, 60);
  pg.addColorStop(0, 'rgba(255,255,255,1)');
  pg.addColorStop(0.35, 'rgba(255,255,255,0.65)');
  pg.addColorStop(1, 'rgba(255,255,255,0)');
  partCtx.fillStyle = pg;
  partCtx.fillRect(0, 0, 128, 128);
  const particleGlow = new THREE.CanvasTexture(partCanvas);
  particleGlow.colorSpace = THREE.SRGBColorSpace;

  // 5. Soft Contact Shadow
  const [shadCanvas, shadCtx] = makeCanvas(256, 256);
  const sg = shadCtx.createRadialGradient(128, 128, 18, 128, 128, 120);
  sg.addColorStop(0, 'rgba(0,0,0,0.85)');
  sg.addColorStop(0.55, 'rgba(0,0,0,0.45)');
  sg.addColorStop(1, 'rgba(0,0,0,0)');
  shadCtx.fillStyle = sg;
  shadCtx.fillRect(0, 0, 256, 256);
  const contactShadow = new THREE.CanvasTexture(shadCanvas);
  contactShadow.colorSpace = THREE.SRGBColorSpace;

  // 6. Brazilian Yellow Diamond "LOMBADA" Sign
  const [signCanvas, signCtx] = makeCanvas(256, 256);
  signCtx.fillStyle = '#eab308';
  signCtx.fillRect(0, 0, 256, 256);
  signCtx.strokeStyle = '#111111';
  signCtx.lineWidth = 14;
  signCtx.strokeRect(14, 14, 228, 228);
  // Speed bump silhouette rotated for diamond UV
  signCtx.fillStyle = '#111111';
  signCtx.beginPath();
  signCtx.moveTo(45, 165);
  signCtx.lineTo(95, 165);
  signCtx.quadraticCurveTo(128, 110, 161, 165);
  signCtx.lineTo(211, 165);
  signCtx.lineTo(211, 182);
  signCtx.lineTo(45, 182);
  signCtx.closePath();
  signCtx.fill();
  const signLombadaMap = new THREE.CanvasTexture(signCanvas);
  signLombadaMap.colorSpace = THREE.SRGBColorSpace;
  signLombadaMap.anisotropy = maxAnisotropy;

  return {
    asphaltMap,
    asphaltRoughness,
    brickMap,
    concreteMap,
    roofMap,
    gloveMap,
    skyMap,
    carbonMap,
    particleGlow,
    contactShadow,
    signLombadaMap,
    dispose: () => {
      asphaltMap.dispose();
      asphaltRoughness.dispose();
      brickMap.dispose();
      concreteMap.dispose();
      roofMap.dispose();
      gloveMap.dispose();
      skyMap.dispose();
      carbonMap.dispose();
      particleGlow.dispose();
      contactShadow.dispose();
      signLombadaMap.dispose();
    },
  };
}
